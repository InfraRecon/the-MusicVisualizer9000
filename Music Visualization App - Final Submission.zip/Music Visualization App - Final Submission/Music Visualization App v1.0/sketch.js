/// VARIABLES///
//global for the controls and input 
var controls = null;
//store visualisations in a container
var vis = null;
//variable for the p5 sound object
var sound = null;
//variable for p5 fast fourier transform
var fourier;
//variable for microphone {EXPERIMENTAL}
var microphone;
//Variable for aplitude
var amplitude;
// Music File Tags
var artist = '';
var track = '';
var album = '';
//Audio Variable
var audio;
var songBar = null;
var loadingScreen = null;
var settings = false;
var menu = false;
var mic = true;
var lock = false;
//Image Variables
var SpaceShipIMG;
var SettingsIMG;
var VolumeIMG;
var MuteIMG;
var MicIMG;
var NoMicIMG;
var MusicIMG;
// RGBA Variables
var Red_Colour = 0;
var Green_Colour = 0;
var Blue_Colour = 0;
var Alpha_Fill = 0;
//Modifiction Variables
var Seed = 0;
var Deform = 0;
var Visualisation = 0;
var Amplitude = 1;
var Speed = 1;
var Velocity = 5;
var Divisions = 5;
var StrokeSize = 1;
var ShapeSize = 1;
var RandomSpaceImage = 1;
var RandomVehicle = 1;
//Setting variables
var Filter;
var cursorType;
var CursorValue = 1;
var CParticles = false;
var CParticleType;
var CParticleValue;
var shapeType;
var visType;
var musicBarValue = 0;
var musicBarType;
//Song Time Variables
var soundlength;
var hours;
var minutes;
var seconds;
var currentMinutes;
var currentSeconds;
var songCurrentTime;
var songCurrentTimetemp = 0;
//Music Array, song, sound variable
var MyMusic = [];
var song;
var sound = null;
//Canvas Variable
var cnv;

//Background random Variables
var randomR;
var randomG;
var randomB;
var ModeColor;
var img;
var visual;
//Frame Count Variable
var frames;
var showFrames = false;
//Star Menu and Loading Screen variables
var startMenu = false;
var loadingS = true;
var about = false;
//Fullscreen Variable
var fs;
//---------------------------------------------------------------//
//Music
// I added some music in an array to try out in the app
var Music = ["stomper_reggae_bit",
             "Marvels Ant Man_ Official Main Theme (by Christophe Beck) ( 256kbps cbr )",
             "ElectroSWING  Jamie Berry Feat. Octavia Rose - Lost In the Rhythm 128 kbps",
             "ACDC - BACK IN BLACK MUSIC WITH LYRICS 128 kbps",
             "JoJo's Bizarre AdventureGolden Wind OST ~Giorno's Theme~ Il vento d'or 128 kbps",
             "Kings & Creatures - Lust & Giants by AEPH 128 kbps"];

//0 - stomper_reggae_bit
//1 - Marvels Ant Man_ Official Main Theme (by Christophe Beck) ( 256kbps cbr )
//2 - ElectroSWING  Jamie Berry Feat. Octavia Rose - Lost In the Rhythm 128 kbps
//3 - ACDC - BACK IN BLACK MUSIC WITH LYRICS 128 kbps
//4 - JoJo's Bizarre AdventureGolden Wind OST ~Giorno's Theme~ Il vento d'or 128 kbps
//5 - Kings & Creatures - Lust & Giants by AEPH 128 kbps
//---------------------------------------------------------------//

//PRELOAD FUNCTION
function preload()
{        
    //Preload Images
    //Music bar Images
    SettingsIMG = 
    loadImage("assets/Settings White.png");
    NotepadIMG = 
    loadImage("assets/notebook.png");
    ModIMG = 
    loadImage("assets/Mod.png");
    TutorialIMG = 
    loadImage("assets/tutorial.png");
    LegacyIMG = 
    loadImage("assets/legacy.png");
    VolumeIMG = 
    loadImage("assets/Volume.png");
    MuteIMG = 
    loadImage("assets/Mute.png");
    MicIMG = 
    loadImage("assets/Mic.png");   
    NoMicIMG = 
    loadImage("assets/No Mic.png");  
    LockIMG = 
    loadImage("assets/Lock.png"); 
    UnLockIMG = 
    loadImage("assets/unLock.png"); 
    MusicIMG = 
    loadImage("assets/Music.png");
    LoopIMG = 
    loadImage("assets/Loop.png");
    
    //Wandering in Space images
    Space01IMG = 
    loadImage("assets/Space Image 01.jpg");
    Space02IMG = 
    loadImage("assets/Space Image 02.jpg");
    Space03IMG = 
    loadImage("assets/Space Image 03.jpg");
    Space04IMG = 
    loadImage("assets/Space Image 04.jpg");
    Space05IMG = 
    loadImage("assets/Space Image 05.jpg");
    //Vehicles
    SpaceCockpitIMG = 
    loadImage("assets/Images/SpaceCockpitTP.png");
    SpaceCockpit01IMG = 
    loadImage("assets/Images/SpaceCockpit01TP.png");
    
    ///WWW Images
    AMDIMG = 
    loadImage("assets/Images/AMD.png");
    AppleIMG = 
    loadImage("assets/Images/Apple.png");
    facebookIMG = 
    loadImage("assets/Images/facebook.png");
    FirefoxIMG = 
    loadImage("assets/Images/FireFox.png");
    GoogleIMG = 
    loadImage("assets/Images/Google.png");
    intelIMG = 
    loadImage("assets/Images/intel.png");
    LinuxIMG = 
    loadImage("assets/Images/Linux.png");
    MicrosoftIMG = 
    loadImage("assets/Images/microsoft.png");
    NvidiaIMG = 
    loadImage("assets/Images/Nvidia.png");
    SONYIMG = 
    loadImage("assets/Images/SONY.png");
    twitterIMG = 
    loadImage("assets/Images/Twitter.png");
    WhatsAppIMG = 
    loadImage("assets/Images/WhatsApp.png");
    //--round versions
    AMDroundIMG = 
    loadImage("assets/Images/AMD round.png");
    AppleroundIMG = 
    loadImage("assets/Images/Apple round.png");
    facebookroundIMG = 
    loadImage("assets/Images/facebook round.png");
    FirefoxroundIMG = 
    loadImage("assets/Images/FireFox round.png");
    GoogleroundIMG = 
    loadImage("assets/Images/Google round.png");
    intelroundIMG = 
    loadImage("assets/Images/intel round.png");
    LinuxroundIMG = 
    loadImage("assets/Images/Linux round.png");
    MicrosoftroundIMG = 
    loadImage("assets/Images/microsoft round.png");
    NvidiaroundIMG = 
    loadImage("assets/Images/Nvidia round.png");
    SONYroundIMG = 
    loadImage("assets/Images/SONY round.png");
    twitterroundIMG = 
    loadImage("assets/Images/Twitter round.png");
    WhatsApproundIMG = 
    loadImage("assets/Images/WhatsApp round.png");
    
    //Preload Sound
    for (var i = 0; i <= 5; i++)
    {
        songName = Music[i] + ".mp3";
        song = 
        loadSound("assets/Music/" + songName); 
        MyMusic.push(song);
    }
    num = 5;
    songName = Music[num];
    sound = MyMusic[num];
}

//---------------------------------------------------------------//

//SETUP FUNCTION
function setup()
{   
    // Canvas, Background
    cnv = 
    createCanvas(windowWidth, windowHeight);
    background(0);
    
    //Controls, Song bar
    controls = new ControlsAndInput();
    songBar = new songBar();
    StartMenu = new StartMenu();
    loadingScreen = new loadingScreen();
    Cursor = new Cursor();
    
    //microphone
    microphone = new p5.AudioIn();
    
    //Visualizations
    //create a new visualisation container and add visualisations
    vis = new Visualisations();
    vis.add(new Beat());
    vis.add(new vertexMesh());
    vis.add(new vertexChord());
    vis.add(new WavePattern());
    vis.add(new Needles());
    vis.add(new Hologram());
    vis.add(new Retroblocks());
    vis.add(new rainParticles());
    vis.add(new Moctaves());
    vis.add(new quantumUnstable());
    vis.add(new Waves());
    vis.add(new Space());
    vis.add(new A2());
    vis.add(new time());
    vis.add(new Matrix());
    vis.add(new WorldWideWeb());
    vis.add(new PureEnergy());
    
    //Background Color Randomized
    // Chaneged so the app is not too bright
    //R
    randomR = 
    random(0,100);
    //G
    randomG = 
    random(0,100);
    //B
    randomB = 
    random(0,100);
    
    //Frame Rate most monitors and TVs have a 60Hz refresh rate
    frameRate(60); //<- can be set to 30fps
    //colour mode
    colorMode(RGB,100);
}

//---------------------------------------------------------------//

//DRAW FUNCTION
function draw()
{   
    //Background Refresh
    background(randomR,     //Random Value 0 - *255
               randomG,     //Random Value 0 - *255
               randomB);    //Random Value 0 - *255
    
    //draw the selected visualisation
    vis.selectedVisual.draw();
    
    //draw the controls on top.
    controls.draw();

    //draw the song bar
    songBar.draw();
    
    //draw the start menu
    StartMenu.draw();
    
    //draw the loading screen
    
    loadingScreen.draw();
    
    //draw the Mouse Cursor
    Cursor.draw();

    //Colour mode
    colorMode(ModeColor,100);
}

//---------------------------------------------------------------//

// MOUSE CLICK FUNCTION
function mouseClicked()
{
	controls.mousePressed();
}

//---------------------------------------------------------------//

// KEY PRESSED FUNCTION
function keyPressed()
{
	controls.keyPressed(keyCode);
}

//---------------------------------------------------------------//

// WINDOW RESIZE FUNCTION
//when the window has been resized. Resize canvas to fit 
//if the visualisation needs to be resized call its onResize method
function windowResized()
{
	resizeCanvas(windowWidth, 
                 windowHeight);
	if(vis.selectedVisual.hasOwnProperty('onResize'))
    {
		vis.selectedVisual.onResize();
	}
}

//---------------------------------------------------------------//
//END