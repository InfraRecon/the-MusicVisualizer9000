/*
    Created by "CHE YU WU"
    Visualization Name: 200524 Quantum Unstable
    
    How I implemeted the code:
    Thsi Visualization is a very cool representation of some sort of unstable like partcle.
    Problems with the code that i found were that the code did not have any ending semi-colons. The code also had no flow so I went a head and cleaned up all the unessesary code and indented it so it makes sense.
    I also had to code and implement changes to the code so that it would react to the music being played.
*/

function quantumUnstable()
{
    
    this.name = "Quantum Unstable";
    
    push();
    let colors = "3d348b-7678ed-f7b801-f18701-f35b04".split("-").map(a=>"#"+a)
    let overAllTexture
    
    this.frequencyBins = ["bass", 
                          "lowMid", 
                          "highMid", 
                          "treble"];

    this.draw = function() 
    {   
        push();
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        
        background(0);
		translate(width/2,height/2);
        scale(0.5);
	    let totalRotate = frameCount/(500/Velocity) + 
            mouseX/100 + 
            noise(frameCount/1000)*5;
		rotate(totalRotate);
	
		noFill();
		strokeWeight(energytreb/5 + StrokeSize);
        stroke(Red_Colour,
               Green_Colour,
               Blue_Colour,
               150);
        
		ellipse(0,0,width);
		stroke(255);
		line(980,0,950,0);
		line(-980,0,-950,0);
		line(0,-980,0,-920);
		line(0,980,0,920);
		ellipse(0,1150,50,20);
		ellipse(0,-1150,50,20);
		ellipse(0,1180,30,10);
		ellipse(0,-1180,30,10);
		noStroke();
		fill(255);
		textSize(40);
		text(totalRotate.toFixed(2),1100,30);
		
        scale(0.5);
		noFill();
		blendMode(SCREEN);
	
        for(var i=0;i<200;i+=10)
        {
            stroke(255,50);
            arc(0,0,1200,1200,PI/200*i,PI/200*i+0.035);
        }
        
        noStroke();
        fill(Red_Colour,Green_Colour,Blue_Colour);
        ellipse(random(-Seed,Seed) + (noise(frameCount/5,10)-0.5) * energyBass/2,
                random(-Seed,Seed) + (noise(frameCount/3,1000)-0.5) * energyBass/2,
                30 + noise(frameCount/10) * random(1,energyBass/2) + ShapeSize*2);
        noFill();

        for(var i=0;i<width;i+=100)
        {
            beginShape()
            strokeWeight(energytreb/5 + StrokeSize + random(-2,2));
            let rr = (width-i)*0.5;
            // ellipse(0,0,width-i)
            let clr = color(colors[int(i/100)%5]);
            clr.setAlpha(150);
            stroke(clr);

            let cc = color(clr);
            cc.setAlpha(100);
            drawingContext.shadowColor =cc;
            for(var o=0;o<150;o+=5)
            {
                let stAng =0 ;
                let ang = stAng+o/(3+i/5000) + frameCount/(30+o)+mouseY/100;
                let xx = cos(ang)*(rr+i/2) + cos(ang*8+o/100)*rr/200;

                let yy = sin(ang)*(rr-i/10) + sin(ang*8+o/100)*rr/200;
                
                if (Deform == 0)
                {   
                    curveVertex(xx ,yy);
                }

                if (Deform == 1)
                {
                    rect(xx ,yy,
                         3 + ShapeSize,
                         3 + ShapeSize);
                }

                if (Deform == 2)
                {
                    ellipse(xx ,yy,3+ShapeSize);
                }
                

                if (random()<0.1)
                {
                    push();
                    scale(1.4);
                    if (Deform == 0)
                    {   
                        curveVertex(xx,yy);
                    }
                    
                    if (Deform == 1)
                    {
                        rect(xx,yy,
                             3 + ShapeSize,
                             3 + ShapeSize);
                    }
                    
                    if (Deform == 2)
                    {
                        ellipse(xx,yy,
                                3 + ShapeSize);
                    }
                    
                    pop();
                }
            }
            endShape();
        }
       pop();
       push();
          blendMode(MULTIPLY);
       pop();
    }
    pop();
}