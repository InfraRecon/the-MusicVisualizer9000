//EXPERIMENTAL EXTENSION
function Retroblocks()
{
    //vas name
	this.name = "Spectro";

	this.draw = function()
    {
        background(0); 
        
        push();
        var spectrum = fourier.analyze(); //spectrum
        
        //Spectrum loop
        for (var i = 0; i< spectrum.length; i++)
        {
            var red = 
            map(spectrum[i + Red_Colour], 0, 255, 255, 0); // red
            var green = 
            map(spectrum[i + Green_Colour], 0, 255, 255, 0); // green
            var blue = 
            map(spectrum[i + Blue_Colour], 0, 255, 255, 0); // blue
            var alpha = Alpha_Fill; // alpha
            
            noFill();
            stroke(red, green, blue);
            strokeWeight(StrokeSize);
            
            // X pos, height
            var x = 
            map(i, 0, spectrum.length, 0, width);
            var h = -height +
            map(spectrum[i], 0, 255, height, 0);
            
            //fill
            fill(random(0,Seed),
                 random(0,Seed),
                 random(0,Seed),
                 255 - alpha);
            
            //Shape Deform
            //Line
            if (Deform == 0)
            {
                strokeWeight(5 + StrokeSize);
                stroke(100 + Red_Colour, 
                       Green_Colour, 
                       Blue_Colour);
                
                point(x,Velocity/10 * height + h);  
            }
            
            //RECT
            if (Deform == 1)
            {
                rect(x, Velocity/10 * height, 
                     ShapeSize + spectrum.length/width, h);  
                
                rect(x, Velocity/10 * height, 
                     ShapeSize + spectrum.length/width, -h);  
            }
            
            //ELLIPSE
            if (Deform == 2)
            {
                ellipse(x, Velocity/10 * height, 
                        ShapeSize + spectrum.length/width, h * 2 );  
            }
        }	
		pop();
	};
}