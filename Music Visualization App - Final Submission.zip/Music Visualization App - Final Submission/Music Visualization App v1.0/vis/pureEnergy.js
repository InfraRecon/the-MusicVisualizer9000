function PureEnergy()
{
    this.name = "Pure Energy";
    this.draw = function()
    {
        push();
        background(0);
        
        //Frequency Bins
        this.frequencyBins = ["bass", 
                              "lowMid", 
                              "highMid", 
                              "treble"];
    
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); 
        //ENERGY Treble initialisation
        
        //Blob Variables
        n = 200; // number of blobs
        radius = 2; // diameter of the circle
        inter = 1; // difference between the sizes of two blobs
        maxNoise = windowHeight/2 - 500 + 
                  (ShapeSize * 10) - energytreb * 10.24;
        noiseProg = (x) => (x*x);
        
        step = 0.01;

        var t = frameCount/250;
        kMax = noise(t/2);
        if (!loadingS && 
            !startMenu)
        {
            frameCount = 0;
        }
        
        strokeWeight(StrokeSize);
        stroke(Red_Colour,
               Green_Colour,
               Blue_Colour,
               Alpha_Fill/255 * 5);
        //Energy Visualization (TREBLE)
        for (var i = n; i >= 0; i--) 
        {
            var alpha = 1 - noiseProg(i / n);
            fill(interpolateSinebow((i/n - t*2)/5 - energyHigh/1024 * 4, alpha*255));
            var size = radius + i * inter;
            var k = kMax * sqrt(i/n);
            var noisiness = maxNoise * noiseProg(i / n);
            blob(size, width/2 + random(-energyBass/1024 * Seed/5,
                                        energyBass/1024 * Seed/5), 
                 height/2 + random(-energyBass/1024 * Seed/5,
                                   energyBass/1024 * Seed/5), 
                 k, t + i * step, noisiness);
        }
        pop();
    }
}