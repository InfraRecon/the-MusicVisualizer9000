let hr = 0;
let id = '';

function time() 
{
    this.name = "Music Clock";
    this.frequencyBins = ["bass", 
                          "lowMid", 
                          "highMid",
                          "treble"];

    this.draw = function() 
    {
        push();
        blendMode(BLEND);
        background(0);
        translate(width / 2, 
                  height / 2);
        push();
        rotate(-HALF_PI);
        drawUnits();
        blendMode(ADD);
        strokeCap(SQUARE);
        strokeWeight(50);
        noFill();
        
        var spectrum = fourier.analyze(); //Spectrum Analysed
    
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        energyBass = energyBass/1024 * PI * 8;
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        energyLow = energyLow/1024 * PI * 8;
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        energyHigh = energyHigh/1024 * PI * 8;
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        energytreb = energytreb/1024 * PI * 8;
        
        // HOURS
        var w = 300;
        var h = 300;
        var start = 0;
        var stop = 
        map(hour() + minute()/60, 0, 12, 0, TWO_PI);
        stroke(energyHigh, 
               Green_Colour, 
               Blue_Colour);
        arc(0, 0, w, h, start, stop);
        
        stroke(energyHigh , 
               Green_Colour, 
               Blue_Colour);
        arc(0, 0, w*2.2, h*2.2, start, energyHigh);
        
        // MINUTES
        w = 400;
        h = 400;
        stop = map(minute() + second()/60, 0, 60, 0, TWO_PI);
        stroke(Red_Colour,energyBass, Blue_Colour);
        arc(0, 0, w, h, start, stop);
        
        stroke(Red_Colour, 
               energyBass, 
               Blue_Colour);
        arc(0, 0, w*2.2, h*2.2, start, energyBass);
        
        //SECONDS
        w = 500;
        h = 500;
        stop = 
        map(second(), 0, 60, 0, TWO_PI);
        stroke(Red_Colour, 
               Green_Colour, 
               energytreb);
        arc(0, 0, w, h, start, stop);
        
        stroke(Red_Colour , 
               Green_Colour, 
               energytreb);
        arc(0, 0, w*2.2, h*2.2, start, energytreb);
        pop();
        showText();
        pop();
    }
}

function drawUnits() 
{
	stroke(128);
	strokeWeight(3);
	// HOURS
	var unit = TWO_PI / 12.0;
	for (var i = 0; i < 12; i++) 
    {
		var a = i * unit;
		var r = 125;
		var x1 = sin(a) * r;
		var y1 = cos(a) * r;
		r = r + 50;
		var x2 = sin(a) * r;
		var y2 = cos(a) * r;
		line(x1, y1, x2, y2);
	}
	
	// MINUTES
	unit = TWO_PI / 60.0;
	for (var i = 0; i < 60; i++) 
    {
		var a = i * unit;
		var r = 175;
		var x1 = sin(a) * r;
		var y1 = cos(a) * r;
		r = r + 50;
		var x2 = sin(a) * r;
		var y2 = cos(a) * r;
		line(x1, y1, x2, y2);
	}
		// SECONDS
	unit = TWO_PI / 60.0;
	for (var i = 0; i < 60; i++) 
    {
		var a = i * unit;
		var r = 225;
		var x1 = sin(a) * r;
		var y1 = cos(a) * r;
		let ext = 0;
		if (i%5 == 0) ext = 15;
		r = r + 50 + ext;
		var x2 = sin(a) * r;
		var y2 = cos(a) * r;
		line(x1, y1, x2, y2);
	}
}

function showText() 
{
	fill(255);
	noStroke();
	textSize(60);
	textAlign(CENTER, CENTER);
	hr = hour();
	id = 'AM';
	if (hour() > 12)
    {
        hr = hour() - 12;
		id = 'PM';
	}
	
	var s = nf(hr, 1) + ":" + 
        nf(minute(), 2) + ":" + 
        nf(second(), 2);
	text(s, 0, -10);
	textSize(45);
    text(id, 0, 50);
}