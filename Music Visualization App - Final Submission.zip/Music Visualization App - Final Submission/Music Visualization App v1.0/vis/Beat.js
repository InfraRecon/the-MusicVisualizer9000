//BEAT EXTENSION 1
function Beat()
{   
    this.name = "Beat"; // Visualization Name
    
    //Frequency Bins
    this.frequencyBins = ["bass", "lowMid", "highMid", "treble"];
    
    //BEAT DRAW
    this.draw = function()
    {
        push(); //<-- so it doesnt affect the other visualistaions
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        
        //Spectrum Colour , Size Loop
        for (var i = 0; i < spectrum.length; i++)
        {   
            var red = map(spectrum[i + Red_Colour], 0, 255, 255, 0); // red
            var green = map(spectrum[i + Green_Colour], 0, 255, 255, 0); // green
            var blue = map(spectrum[i + Blue_Colour], 0, 255, 255, 0); // blue
            var alpha = 255 - Alpha_Fill; //Transparency

            var sizeSpectrum = 500 + map(spectrum[i],0,1000,0,500); // Size
        }
        
        // EDGING for the RECT
        var edging = 0;
        
        strokeWeight(StrokeSize);
        
        // DEFORM for Visualization
        //LINE DEFORM
        if (Deform == 0)
        {
            strokeWeight(StrokeSize + energyBass/5);
            stroke(Red_Colour,0,0,255 - Alpha_Fill);

            line(random(width/2,width/2) - (100 + ShapeSize) - energyBass/2,
                 random(height/2,height/2) - (100 + ShapeSize),
                 random(width/2,width/2) + (100 + ShapeSize) + energyBass/2,
                 random(height/2,height/2) - (100 + ShapeSize));

            strokeWeight(StrokeSize + energyLow/5);
            stroke(Red_Colour,0,Blue_Colour,255 - Alpha_Fill);

            line(random(width/2,width/2) - (100 + ShapeSize) - energyLow/2,
                 random(height/2,height/2) - (50 + ShapeSize),
                 random(width/2,width/2) + (100 + ShapeSize) + energyLow/2,
                 random(height/2,height/2) - (50 + ShapeSize));

            strokeWeight(StrokeSize + energytreb/5);
            stroke(0,Green_Colour,0,255 - Alpha_Fill);

            line(random(width/2,width/2) - (100 + ShapeSize) - energytreb/2,
                 random(height/2,height/2),
                 random(width/2,width/2) + (100 + ShapeSize) + energytreb/2,
                 random(height/2,height/2));

            strokeWeight(StrokeSize + energyHigh/5);
            stroke(0,0,Blue_Colour,255 - Alpha_Fill);

            line(random(width/2,width/2) - (100 + ShapeSize) - energyHigh/2,
                 random(height/2,height/2) + (50 + ShapeSize),
                 random(width/2,width/2) + (100 + ShapeSize) + energyHigh/2,
                 random(height/2,height/2) + (50 + ShapeSize));

        }

        //RECT DEFORM
        if (Deform == 1)
        {
            //STROKE & STROKEWEIGHT
            stroke(Red_Colour,Green_Colour,Blue_Colour);

            //ENERGY BASS RECT
            fill(200,255 - Alpha_Fill);
            rect(width/2 - random(0,energyBass/1024 * (Velocity * 2)) - (300 + energyBass)/2 - ShapeSize/2, 
                height/2 - random(0,energyBass/1024 * (Velocity * 2)) - (300 + energyBass)/2 - ShapeSize/2, 
                    300 + ShapeSize*2 + energyBass,
                    300 + ShapeSize*2 + energyBass, edging);

            //ENERGY LOW RECT
            fill(Red_Colour,0,0,255 - Alpha_Fill);
            rect(width/2 - random(0,energyLow/1024 * (Velocity * 2)) - (100 + energyLow)/2 - ShapeSize/2, 
                height/2 - random(0,energyLow/1024 * (Velocity * 2)) -  (100 + energyLow)/2 - ShapeSize/2, 
                    100 + ShapeSize*2 + energyLow,
                    100 + ShapeSize*2 + energyLow, edging);

            //ENERGY HIGH RECT
            fill(0,Green_Colour,0,255 - Alpha_Fill);
            rect(width/2 - random(0,energyHigh/1024 * (Velocity * 2)) - (100 + energyHigh)/2 - ShapeSize/2, 
                height/2 - random(0,energyHigh/1024 * (Velocity * 2)) - (100 + energyHigh)/2 - ShapeSize/2, 
                    100 + ShapeSize*2 + energyHigh,
                    100 + ShapeSize*2 + energyHigh, edging);

            //ENERGY TREBLE RECT
            fill(0,0,Blue_Colour,255 - Alpha_Fill);
            rect(width/2 - random(0,energytreb/1024 * (Velocity * 2)) - (50 + energytreb)/2 - ShapeSize/2, 
                height/2 - random(0,energytreb/1024 * (Velocity * 2)) - (50 + energytreb)/2 - ShapeSize/2, 
                    50 + ShapeSize*2 + energytreb,
                    50 + ShapeSize*2 + energytreb, edging);
        }

        //ELLIPSE DEFORM
        if (Deform == 2)
        {       
            //STROKE & STROKEWEIGHT
            stroke(Red_Colour,Green_Colour,Blue_Colour);

            //ENERGY BASS ELLIPSE
            fill(200,255 - Alpha_Fill);
            ellipse(width/2
                    - random(0,energyBass/1024 * (Velocity * 2)), 
                height/2
                    - random(0,energyBass/1024 * (Velocity * 2)), 
                    300 + ShapeSize*2 + energyBass,
                    300 + ShapeSize*2 + energyBass);

            //ENERGY LOW ELLIPSE
            fill(Red_Colour,0,0,255 - Alpha_Fill);
            ellipse(width/2
                    - random(0,energyLow/1024 * (Velocity * 2)), 
                height/2 
                    - random(0,energyLow/1024 * (Velocity * 2)), 
                    100 + ShapeSize*2 + energyLow,
                    100 + ShapeSize*2 + energyLow);

            //ENERGY HIGH ELLIPSE
            fill(0,Green_Colour,0,255 - Alpha_Fill);
            ellipse(width/2
                    - random(0,energyHigh/1024 * (Velocity * 2)), 
                height/2
                    - random(0,energyHigh/1024 * (Velocity * 2)), 
                    100 + ShapeSize*2 + energyHigh,
                    100 + ShapeSize*2 + energyHigh);

            //ENERGY TREBLE ELLIPSE
            fill(0,0,Blue_Colour,255 - Alpha_Fill);
            ellipse(width/2
                    - random(0,energytreb/1024 * (Velocity * 2)), 
                height/2 
                    - random(0,energytreb/1024 * (Velocity * 2)), 
                    50 + ShapeSize*2 + energytreb,
                    50 + ShapeSize*2 + energytreb);
        }
        pop();
    }
}
