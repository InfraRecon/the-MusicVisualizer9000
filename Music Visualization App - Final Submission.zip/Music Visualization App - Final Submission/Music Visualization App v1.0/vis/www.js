let _aryObject = [];
let _tileNumT;
let _tileNumR;
let _ellipseRatio;
let _count;
let _stepR;
let _stepT;
let _rRate;

var _randomImage;
var frequencyBins = ["bass", "lowMid", "highMid", "treble"];

class f 
{
    constructor(iR, iT, myColor, shapeMode, sw) 
    {
        this.target_iR = iR;
        this.target_iT = iT;
        this.myColor = myColor;
        this.shapeMode = shapeMode; //0 rect, 1 ellipse
            this.sw = sw *_ellipseRatio; 
        this.aryPoint = [];
    }

    setTarget() 
    {
        _stepR = int(random(_tileNumR/2))+1;
        _stepT = 1; //int(random(_tileNumT/30))+1;
        this.iR = this.target_iR;
        this.target_iT = this.target_iT % _tileNumT;
        this.iT = this.target_iT;

        this.aryPoint.unshift([this.iR, this.iT]);

        let dir;
        if (this.iR <= _stepR) 
        {
          dir = random(["down", "left", "right"]);
        } 
        else if (this.iR >= _tileNumR-_stepR) 
        {
          dir = random(["up", "left", "right"]);
        } 
        else 
        {
          dir = random(["up", "down", "left", "right"]);
        }

        if (dir == "up") 
        { 
            this.target_iR = this.iR - _stepR; 
        }
        else if (dir == "down") 
        { 
            this.target_iR = this.iR + _stepR; 
        }
        else if (dir == "left") 
        { 
            this.target_iT = this.iT - _stepT; 
        }
        else if (dir == "right") 
        {
            this.target_iT = this.iT + _stepT; 
        }

        this.dR = (this.target_iR - this.iR) / (_freqCount+0.5);
        this.dT = (this.target_iT - this.iT) / (_freqCount+0.5);
  }
  
    update() 
    {
        if (_count % _freqCount == 0) 
        {
            this.setTarget();
        }

        if (this.target_iR == this.iR) { //dir = right or left
          this.aryPoint.unshift([this.iR, this.aryPoint[0][1] + (this.target_iT - this.iT)/2]);
        } 
        else if (this.target_iT == this.iT) 
        {
            this.aryPoint.unshift([this.aryPoint[0][0] + (this.target_iR - this.iR)/2, this.iT]);
        }
        this.iR = this.aryPoint[0][0];
        this.iT = this.aryPoint[0][1];

        while (this.aryPoint.length >= 100) 
        {
            this.aryPoint.pop();
        }

        for (let i = 0; i < this.aryPoint.length; i++) 
        {
            this.aryPoint[i][0] *= _rRate;
        }
    }

    drawMe() 
    {
        push();
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(frequencyBins[0]); //ENERGY BASS 
        var energyLow = fourier.getEnergy(frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(frequencyBins[3]); //ENERGY Treble initialisation

        translate(width/2, height/2);
        
        noFill();
        strokeWeight(width/400 + energytreb/10);
        stroke(this.myColor);
        beginShape();
        for (let i = 0; i < this.aryPoint.length; i++) 
        {
          vertex(width / 2 / _tileNumR * 
                 this.aryPoint[i][0] * 
                 cos(2*PI / _tileNumT * 
                 this.aryPoint[i][1]),
                 width / 2 / _tileNumR * 
                 this.aryPoint[i][0] * 
                 sin(2*PI / _tileNumT * 
                 this.aryPoint[i][1]));
        }
        endShape();

        stroke(Red_Colour,
           Green_Colour,
           Blue_Colour);

        strokeWeight(1 + StrokeSize);
        fill(this.myColor);
        for (let i = 0; i < this.aryPoint.length; i++) 
        {
            if (Deform == 0)
            {
                point(
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                cos(2*PI / _tileNumT * 
                this.aryPoint[i][1]),
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                sin(2*PI / _tileNumT * 
                this.aryPoint[i][1]),
                this.sw/i**0.5 + energytreb/2, 
                this.sw/i**0.5 + energytreb/2);
            }

            if (Deform == 1)
            {
                rect(
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                cos(2*PI / _tileNumT * 
                this.aryPoint[i][1]) - (this.sw/i**0.5 + energytreb/2)/2,
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                sin(2*PI / _tileNumT * 
                this.aryPoint[i][1]) - (this.sw/i**0.5 + energytreb/2)/2,
                this.sw/i**0.5 + energytreb/2, 
                this.sw/i**0.5 + energytreb/2);
            }

            if (Deform == 2)
            {
                ellipse(
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                cos(2*PI / _tileNumT * 
                this.aryPoint[i][1]),
                width / 2 / _tileNumR * 
                this.aryPoint[i][0] * 
                sin(2*PI / _tileNumT * 
                this.aryPoint[i][1]),
                this.sw/i**0.5 + energytreb/2,
                this.sw/i**0.5 + energytreb/2);
            }
        }
        pop();
    }
}

function WorldWideWeb() 
{
    this.name = "www.Web";
    let canvasSize;

    frameRate(30);
    colorMode(HSB, 360, 100, 100, 255);
    blendMode(BLEND);
    strokeJoin(ROUND);
    _freqCount = 4;
    _rRate = 0.99;
    _ellipseRatio = 4;
    _count = 0;
    _tileNumT = int(random(3, 16))+1;
    _tileNumR = int(random(15, 32))+1;

    let shapeMode = 1;
    let initT = int(random(_tileNumT));
    let layerNum = 16;
    for (k = 1; k <= layerNum; k++) {
    let baseColor = 360 + random(720);
    _aryObject.push(new f(
      1, initT,
      color((baseColor) % 360, 100, 100, 100),
      shapeMode,
      width/2/_tileNumR
    ));
    }
    
    this.draw = function() 
    {
        push();
        background(10);
        
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(frequencyBins[0]); //ENERGY BASS initialisation
        energyBass = energyBass/1024 * 255;
        var energyLow = fourier.getEnergy(frequencyBins[1]); //ENERGY Low initialisation
        energyLow = energyLow/1024 * 255;
        var energyHigh = fourier.getEnergy(frequencyBins[2]); //ENERGY High initialisation
        energyHigh = energyHigh/1024 * 255;
        var energytreb = fourier.getEnergy(frequencyBins[3]); //ENERGY Treble initialisation
        energytreb = energytreb/1024 * 10;
        
        blendMode(ADD);
        blendMode(BLEND);
        
        for (let i = 0; i < _aryObject.length; i++) 
        {
            _aryObject[i].update();
            _aryObject[i].drawMe();
        }

        _count ++;
        
        var randomImage = _randomImage;
        
        //images square
        if (Deform == 1)
        {
            if (randomImage == 1)
            {
                image(AMDIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 2)
            {
                image(AppleIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 3)
            {
                image(facebookIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 4)
            {
                image(FirefoxIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 5)
            {
                image(GoogleIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 6)
            {
                image(intelIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 7)
            {
                image(LinuxIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 8)
            {
                image(MicrosoftIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 9)
            {
                image(NvidiaIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 10)
            {
                image(SONYIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 11)
            {
                image(twitterIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 12)
            {
                image(WhatsAppIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }
            strokeWeight(5 + StrokeSize + energyBass/5);
            stroke(Red_Colour,
                   Green_Colour,
                   Blue_Colour);
            noFill();
            rect(width/2 - 100,
                 height/2 -100,
                 200,200);
            noStroke();
        }
        
        //images round
        if (Deform == 0 || 
            Deform == 2)
        {
            if (randomImage == 1)
            {
                image(AMDroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 2)
            {
                image(AppleroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 3)
            {
                image(facebookroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 4)
            {
                image(FirefoxroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 5)
            {
                image(GoogleroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 6)
            {
                image(intelroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 7)
            {
                image(LinuxroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 8)
            {
                image(MicrosoftroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 9)
            {
                image(NvidiaroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 10)
            {
                image(SONYroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 11)
            {
                image(twitterroundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }

            if (randomImage == 12)
            {
                image(WhatsApproundIMG,
                      width/2 - 100,
                      height/2 -100,
                      200,200);
            }
            strokeWeight(5 + StrokeSize + energyBass/5);
            stroke(Red_Colour,
                   Green_Colour,
                   Blue_Colour);
            noFill();
            ellipse(width/2,
                    height/2,
                    200,200);
            noStroke();
        }
        pop();
    }
}

//mouse release function
function mouseReleased() 
{
    push();
    _count = 0;
    _tileNumT = int(random(3, 16))+1;
    _tileNumR = int(random(15, 32))+1;

    let shapeMode = 1;
    let initT = int(random(_tileNumT));
    let layerNum = 16;
    _aryObject = [];
    for (k = 1; k <= layerNum; k++) 
    {
        let baseColor = 360 + random(720);
        _aryObject.push(new f(
          1, initT,
          color((baseColor) % 360 + Red_Colour, 
                100 + Green_Colour, 
                100 + Blue_Colour, 100 - Alpha_Fill),
          shapeMode,
          width/2/_tileNumR
        ));
    }
    _randomImage = round(random(1,12));
    pop();
}