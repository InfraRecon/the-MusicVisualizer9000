//SPECTRUM EXTENSION - EXAMPLE 1

///
//////////////////////////Vert Particle Class////////////////////////// {EXPERIMENTAL}
// this class describes the properties of a single particle.
class vertParticle 
{
    // setting the co-ordinates, radius and the
    // speed of a particle in both the co-ordinates axes.
    constructor()
    {
        this.x = random(11,width - 9);
        this.y = random(11,height - 9);
        
        this.x1 = random(11,width - 9);
        this.y1 = random(11,height - 9);
        
        this.x2 = random(11,width - 9);
        this.y2 = random(11,height - 9);
        
        this.x3 = width/2;
        this.y3 = height/2;
        
        this.x4 = width/2;
        this.y4 = height/2;
        
        this.x5 = width/2;
        this.y5 = height/2;
        
        this.x6 = width/2;
        this.y6 = height/2;
        
        this.r = random(5,10);
        this.xSpeed = random(-1,1);
        this.ySpeed = random(-0.5,0.5);
        
        this.x1Speed = random(-2,2);
        this.y1Speed = random(-1,1.5);
        
        this.x2Speed = random(-4,4);
        this.y2Speed = random(-2,2.5);
        
        ///
        this.x3Speed = random(-0.5,0.5);
        this.y3Speed = random(-0.25,0.75);
        
        this.x4Speed = random(-0.5,0.5);
        this.y4Speed = random(-0.25,0.75);
        
        this.x5Speed = random(-0.5,0.5);
        this.y5Speed = random(-0.25,0.75);
        
        this.x6Speed = random(-0.5,0.5);
        this.y6Speed = random(-0.25,0.75);
    }
    
    // this function creates the connections(lines)
    // between particles which are less than a certain distance apart
    joinParticles(particles) 
    {
        particles.forEach(element =>
        {
            //Frequency Bins
            this.frequencyBins = ["bass", 
                                  "lowMid", 
                                  "highMid", 
                                  "treble"];
            var spectrum = fourier.analyze(); //Spectrum Analysed
            var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
            var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
            var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
            var energytreb = fourier.getEnergy(this.frequencyBins[3]);
            
            var dis = dist(this.x,this.y,element.x,element.y);
            
            var dis1 = dist(this.x1,this.y1,element.x1,element.y1);
            
            var dis2 = dist(this.x2,this.y2,element.x2,element.y2);
            
            if(dis < 100) 
            {
                stroke(energytreb + Red_Colour,
                        random(0,energytreb) + Green_Colour,
                        random(0,energytreb) + Blue_Colour,
                        energyBass * 2 - Alpha_Fill);
                
                line(this.x,this.y,element.x,element.y);
            }
            
            if(dis1 < 125) 
            {   
                stroke(random(0,energytreb) + Red_Colour,
                        energytreb + Green_Colour,
                        random(0,energytreb) + Blue_Colour,
                        energyBass * 2 - Alpha_Fill);

                line(this.x1,this.y1,element.x1,element.y1);
            }
            
            if(dis2 < 150) 
            {   
                stroke(random(0,energytreb) + Red_Colour,
                        random(0,energytreb) + Green_Colour,
                        energytreb + Blue_Colour,
                        energyBass * 2 - Alpha_Fill);

                line(this.x2,this.y2,element.x2,element.y2);
            }
        });
    }
    
    createParticle() 
    {
        //Frequency Bins
        this.frequencyBins = ["bass", 
                              "lowMid", 
                              "highMid", 
                              "treble"];
        
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]);//ENERGY Treble initialisation
        
        strokeWeight(StrokeSize);
        stroke(energyBass + Red_Colour,
             random(0,energytreb) + Green_Colour,
             random(0,energytreb) + Blue_Colour,
             255);
        
        fill(energyBass + Red_Colour,
             random(0,energytreb) + Green_Colour,
             random(0,energytreb) + Blue_Colour,
             255 - Alpha_Fill);
        
        if (Deform == 0)
        {
            ellipse(this.x,this.y,this.r/2);
            
            noFill();
            ellipse(this.x,
                    this.y,
                    this.r + ShapeSize + energyBass/10);
        }
        
        if (Deform == 1)
        {
            rect(this.x - (this.r + ShapeSize + energyBass/10)/2,
                 this.y - (this.r + ShapeSize + energyBass/10)/2,
                 this.r + ShapeSize + energyBass/10,
                 this.r + + ShapeSize + energyBass/10);
        }
        
        if (Deform == 2)
        {
            ellipse(this.x,this.y,this.r + ShapeSize + energyBass/10);
        }
        //////////
        stroke(random(0,energytreb)  + Red_Colour,
             energyBass + Green_Colour,
             random(0,energytreb) + Blue_Colour,
             255);
        
        fill(random(0,energytreb)  + Red_Colour,
             energyBass + Green_Colour,
             random(0,energytreb) + Blue_Colour,
             255 - Alpha_Fill);
        
        if (Deform == 0)
        {
            ellipse(this.x1,this.y1,this.r/2);
            
            noFill();
            ellipse(this.x1,this.y1,this.r + ShapeSize + energyBass/20);
        }
        
        if (Deform == 1)
        {
            rect(this.x1 - (this.r + ShapeSize + energyBass/20)/2,
                 this.y2 - (this.r + ShapeSize + energyBass/20)/2,
                 this.r + ShapeSize + energyBass/20,
                 this.r + ShapeSize + energyBass/20);
        }
        
        if (Deform == 2)
        {
            ellipse(this.x1,this.y1,this.r + ShapeSize + energyBass/20);
        }
        
        //////////
        stroke(random(0,energytreb)  + Red_Colour,
               random(0,energytreb) + Green_Colour,
               energyBass + Blue_Colour,
               255);
        
        fill(random(0,energytreb)  + Red_Colour,
             random(0,energytreb) + Green_Colour,
             energyBass + Blue_Colour,
             255 - Alpha_Fill);
        
        if (Deform == 0)
        {
            ellipse(this.x2,this.y2,this.r/2);
            
            noFill();
            ellipse(this.x2,this.y2,this.r + ShapeSize + energyBass/30);
        }
        
        if (Deform == 1)
        {
            rect(this.x2 - (this.r + ShapeSize + energyBass/30)/2,
                 this.y2 - (this.r + ShapeSize + energyBass/30)/2,
                 this.r + ShapeSize + energyBass/30,
                 this.r + ShapeSize + energyBass/30);
        }
        
        if (Deform == 2)
        {
            ellipse(this.x2,this.y2,this.r + ShapeSize + energyBass/30);
        }
    }
    
    // creation of a particle.
    createParticlelarge() 
    {
        //Frequency Bins
        this.frequencyBins = ["bass", 
                              "lowMid", 
                              "highMid", 
                              "treble"];
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]);
        
        //Stroke ,Stroke Weight
        strokeWeight(StrokeSize);
        
        fill(Red_Colour,
               Green_Colour,
               Blue_Colour,
               255 - Alpha_Fill);
        
        stroke(Red_Colour,
               Green_Colour,
               Blue_Colour,
               255 - Alpha_Fill);
        
        ////////////
        var alpha = energyBass; //Alpha
        stroke(energyBass + Red_Colour,
               Green_Colour,
               Blue_Colour,
               alpha);
        
        for (var i = 0; i < energyBass; i++)
        {
            this.angle1 = random(0, (energyBass/energyBass * 2) * PI);
            this.xpos1 = 0 + random(0,Velocity * 2) + 
                         energyBass/2 * cos(this.angle1);
            this.ypos1 = 0 + random(0,Velocity * 2) + 
                         energyBass/2 * sin(this.angle1);

            // find another random point on the circle
            this.angle2 = random(0, (energyBass/energyBass * 2) * PI);
            this.xpos2 = 0 + random(0,Velocity * 2) + 
                         energyBass/2 * cos(this.angle2);
            this.ypos2 = 0 + random(0,Velocity * 2) + 
                         energyBass/2 * sin(this.angle2);
        
            // draw a line between them
            line(this.xpos1 + this.x3, 
                    this.ypos1 + this.y3, 
                    this.xpos2 + this.x3, 
                    this.ypos2 + this.y3);
        }
        
        ///////////
        var alpha = energytreb; //Alpha
            stroke(Red_Colour,
                   energytreb + Green_Colour,
                   Blue_Colour,
                   alpha);
        
        for (var i = 0; i < energytreb; i++)
        {
            this.angle1 = random(0, (energytreb/energytreb * 2) * PI);
            this.xpos1 = 0 + random(0,Velocity * 2) + 
                         energytreb * cos(this.angle1);
            this.ypos1 = 0 + random(0,Velocity * 2) + 
                         energytreb * sin(this.angle1);

            // find another random point on the circle
            this.angle2 = random(0, (energytreb/energytreb * 2) * PI);
            this.xpos2 = 0 + random(0,Velocity * 2) + 
                         energytreb * cos(this.angle2);
            this.ypos2 = 0 + random(0,Velocity * 2) + 
                         energytreb * sin(this.angle2);
        
            // draw a line between them
            line(this.xpos1 + this.x4, 
                    this.ypos1 + this.y4, 
                    this.xpos2 + this.x4, 
                    this.ypos2 + this.y4);
        }
        
        ///////////
        var alpha = energyLow; //Alpha
            stroke(Red_Colour,
                   Green_Colour,
                   energyLow + Blue_Colour,
                   alpha);
        
        for (var i = 0; i < energyLow; i++)
        {
            this.angle1 = random(0, (energyLow/energyLow * 2) * PI);
            this.xpos1 = 0 + random(0,Velocity * 2) + 
                         energyLow * cos(this.angle1);
            this.ypos1 = 0 + random(0,Velocity * 2) + 
                         energyLow * sin(this.angle1);

            // find another random point on the circle
            this.angle2 = random(0, (energyLow/energyLow * 2) * PI);
            this.xpos2 = 0 + random(0,Velocity * 2) + 
                         energyLow * cos(this.angle2);
            this.ypos2 = 0 + random(0,Velocity * 2) + 
                         energyLow * sin(this.angle2);
        
            // draw a line between them
            line(this.xpos1 + this.x5, 
                    this.ypos1 + this.y5, 
                    this.xpos2 + this.x5, 
                    this.ypos2 + this.y5);
        }
        
        ///////////
        var alpha = energyHigh; //Alpha
            stroke(energyHigh + Red_Colour,
                   Green_Colour,
                   energyHigh + Blue_Colour,
                   alpha);
        
        for (var i = 0; i < energyHigh; i++)
        {
            this.angle1 = random(0, (energyHigh/energyHigh * 2) * PI);
            this.xpos1 = 0 + random(0,Velocity * 2) + 
                         energyHigh * cos(this.angle1);
            this.ypos1 = 0 + random(0,Velocity * 2) + 
                         energyHigh * sin(this.angle1);

            // find another random point on the circle
            this.angle2 = random(0, (energyHigh/energyHigh * 2) * PI);
            this.xpos2 = 0 + random(0,Velocity * 2) + 
                         energyHigh * cos(this.angle2);
            this.ypos2 = 0 + random(0,Velocity * 2) +  
                         energyHigh * sin(this.angle2);
        
            // draw a line between them
            line(this.xpos1 + this.x6, 
                 this.ypos1 + this.y6, 
                 this.xpos2 + this.x6, 
                 this.ypos2 + this.y6);
        }
    }

    // setting the particle in motion.
    moveParticle() 
    {   
        if(this.x < 10 || this.x > width -10)
        {
           this.xSpeed*= -1; 
        }
        
        if(this.y < 10 || this.y > height -10)
        {
           this.ySpeed*= -1; 
        }
        
        this.x+=this.xSpeed;
        this.y+=this.ySpeed;
        
        ////////////
        
        if(this.x1 < 10 || this.x1 > width -10)
            this.x1Speed*= -1;
        
        if(this.y1 < 10 || this.y1 > height -10)
            this.y1Speed*= -1;
        
        this.x1+=this.x1Speed;
        this.y1+=this.y1Speed;
        
        ////////////
        
        if(this.x2 < 10 || this.x2 > width -10)
            this.x2Speed*= -1;
        
        if(this.y2 < 10 || this.y2 > height -10)
            this.y2Speed*= -1;
        
        this.x2+=this.x2Speed;
        this.y2+=this.y2Speed;
    }
        
    moveParticlelarge() 
    {
        //red
        if(this.x3 < 150 || this.x3 > width -150)
            this.x3Speed*= -1;
        
        if(this.y3 < 150 || this.y3 > height -150)
            this.y3Speed*= -1;

        this.x3+=this.x3Speed;
        this.y3+=this.x3Speed;
        
        ////////////
        
        //green
        if(this.x4 < 150 || this.x4 > width -150)
            this.x4Speed*= -1;
        
        if(this.y4 < 150 || this.y4 > height -150)
            this.y4Speed*= -1;

        this.x4+=this.x4Speed;
        this.y4+=this.y4Speed;
        
        ////////////
        
        //blue
        if(this.x5 < 150 || this.x5 > width -150)
            this.x5Speed*= -1;
        
        if(this.y5 < 150 || this.y5 > height -150)
            this.y5Speed*= -1;

        this.x5+=this.x5Speed;
        this.y5+=this.y5Speed;
        
        ////////////
        
        //magenta
        if(this.x6 < 150 || this.x6 > width -150)
            this.x6Speed*= -1;
        
        if(this.y6 < 150 || this.y6 > height -150)
            this.y6Speed*= -1;

        this.x6+=this.x6Speed;
        this.y6+=this.y6Speed;
    }
}

// an array to add multiple particles
var vparticles = [];

function vertexMesh()
{
	this.name = "Vertex Particles";
    
    for(var i = 0;i<width/10;i++)
    {
        vparticles.push(new vertParticle());
    }
    
	this.draw = function()
    {
        push();
        
        background(0);
        blendMode(BLEND);
        blendMode(ADD);
        
        //Frequency Bins
        this.frequencyBins = ["bass", 
                              "lowMid", 
                              "highMid", 
                              "treble"];
        
        strokeWeight(StrokeSize);
        for(var i = 0;i < vparticles.length;i++)
        {
            vparticles[i].joinParticles(vparticles.slice(i));
            vparticles[i].createParticle();
            vparticles[i].moveParticle(); 
        }
        
        for(var i = 0;i < 1;i++)
        {
            vparticles[i].createParticlelarge();
            vparticles[i].moveParticlelarge(); 
        }
        
        
        pop();
    }
}
////////