// By Roni Kaufman
// inspired by https://twitter.com/wavegrower/status/1155162807417094146

let stars = [];
let planets = [];
let maxDist;

function Space() 
{
    this.name = "Space Odyssey";
	noStroke();
    maxDist = (windowWidth + windowWidth/8) * 2;
    
	for (let i = 0; i < 1500; i++) 
    {
		stars.push(new Star());
	}
    
    this.frequencyBins = ["bass", 
                          "lowMid", 
                          "highMid", 
                          "treble"];
	
	background(255);

    this.draw = function() 
    {   
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treb initialisation
        
        push();
        background(0);
        background(0 + Red_Colour/5,
                0 + Green_Colour/5,
                0 + Blue_Colour/5,
                255 - energyBass/4);
        
        if (RandomSpaceImage == 1)
        {
            image(Space01IMG,
                  0 + random(-energytreb/20.48,energytreb/20.48) - 
                  mouseX/width * 50,
                  0 + random(-energytreb/20.48,energytreb/20.48) - mouseY/height * 50,
                  windowWidth + 100,
                  windowHeight + 150);
        }
        
        if (RandomSpaceImage == 2)
        {
            image(Space02IMG,
                  0 + random(-energytreb/20.48,energytreb/20.48) - 
                  mouseX/width * 50,
                  0 + random(-energytreb/20.48,energytreb/20.48) - mouseY/height * 50,
                  windowWidth + 100,
                  windowHeight + 150);
        }
        
        if (RandomSpaceImage == 3)
        {
            image(Space03IMG,
                  0 + random(-energytreb/20.48,energytreb/20.48) - 
                  mouseX/width * 50,
                  0 + random(-energytreb/20.48,energytreb/20.48) - mouseY/height * 50,
                  windowWidth + 100,
                  windowHeight + 150);
        }
        
        if (RandomSpaceImage == 4)
        {
            image(Space04IMG,
                  0 + random(-energytreb/20.48,energytreb/20.48) - 
                  mouseX/width * 50,
                  0 + random(-energytreb/20.48,energytreb/20.48) - mouseY/height * 50,
                  windowWidth + 100,
                  windowHeight + 150);
        }
        
        if (RandomSpaceImage == 5)
        {
            image(Space05IMG,
                  0 + random(-energytreb/20.48,energytreb/20.48) - 
                  mouseX/width * 50,
                  0 + random(-energytreb/20.48,energytreb/20.48) - mouseY/height * 50,
                  windowWidth + 100,
                  windowHeight + 150);
        }
        
        fill(5, 15);
        ellipse(width/2, height/2, maxDist);
        translate(width/2 + 
                  random(-energytreb/20.48,energytreb/20.48) 
                  - mouseX/width * 25, 
                  height/2 +
                  random(-energytreb/20.48,energytreb/20.48)
                  - mouseY/height * 25);
        
        blendMode(ADD);
        blendMode(BLEND);
        for (let s of stars) 
        {
            s.drawAndMove();
        }
        pop();
        
        fill(Red_Colour/2,
             Green_Colour/2,
            Blue_Colour/2,
             energyBass/1024 * 100);
        
        rect(0,0,width,height);
        
        if (RandomVehicle == 2)
        {
            image(SpaceCockpitIMG,
              -5 + random(-Seed/20,Seed/20) + 
              mouseX/width * 5,
              -5 + random(-Seed/20,Seed/20) + 
              mouseY/height * 5,
              width + 5, height + 5); 
        }
        
        if (RandomVehicle == 3)
        {
            image(SpaceCockpit01IMG,
              -5 + random(-Seed/20,Seed/20) + 
              mouseX/width * 5,
              -5 + random(-Seed/20,Seed/20) + 
              mouseY/height * 5,
              width + 5, height + 5); 
        } 
    }
}

function Star() 
{   
    this.frequencyBins = ["bass", 
                          "lowMid", 
                          "highMid", 
                          "treble"];
    
    var spectrum = fourier.analyze(); //Spectrum Analysed
    var energyBass = fourier.getEnergy(this.frequencyBins[0]); 
    //ENERGY BASS initialisation
    var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
    var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
    var energytreb = fourier.getEnergy(this.frequencyBins[3]);
    
    this.theta = random(TWO_PI);
    this.speed = random(1.5);
    this.vel = p5.Vector.fromAngle(this.theta, this.speed);
    this.pos = p5.Vector.fromAngle(this.theta, random(maxDist));
    this.colorRed = random(100 + Red_Colour + energyBass);
    this.colorGreen = random(100 + Green_Colour + energyBass);
    this.colorBlue = random(100 + Blue_Colour + energyBass);
	
	this.drawAndMove = function() 
    {
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treb initialisation
        
		let d = dist(this.pos.x, 
                     this.pos.y, 0, 0);
		
		// draw
		let size = sqrt(this.speed) * d/80;
		let alpha = map(d, 0, maxDist/2, 0, 255);
        
        stroke(this.colorRed,
             this.colorGreen,
             this.colorBlue,
               alpha);
        
        strokeWeight(StrokeSize + energyBass/102.4);
        
		fill(this.colorRed,
             this.colorGreen ,
             this.colorBlue,
             alpha);

        if (Deform == 0)
        {
            point(this.pos.x + random(-Seed/10,Seed/10), 
                 this.pos.y + random(-Seed/10,Seed/10), 
                 size + ShapeSize + energyBass/102.4); 

        }

        if (Deform == 1)
        {
            rect(this.pos.x/2 + random(-Seed/10,Seed/10), 
                this.pos.y/2 + random(-Seed/10,Seed/10), 
                size + ShapeSize + energyBass/102.4,
                size + ShapeSize + energyBass/102.4);
        }
        
        if (Deform == 2)
        {
            ellipse(this.pos.x + random(-Seed/10,Seed/10), 
                    this.pos.y + random(-Seed/10,Seed/10), 
                    size + ShapeSize + energyBass/102.4);
        }

		// move
		this.pos.add(p5.Vector.mult(this.vel, sqrt(d)/20 + Velocity * 2));
		
		if (d < 1.5) 
        {
			this.pos = p5.Vector.fromAngle(this.theta, maxDist);
		} 
        
        else if (d > maxDist + 10) 
        {
			this.pos = p5.Vector.fromAngle(this.theta, 10);
		}
	}
}