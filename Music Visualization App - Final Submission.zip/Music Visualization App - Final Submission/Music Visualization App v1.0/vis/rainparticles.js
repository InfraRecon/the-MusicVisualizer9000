//EXTENSION 4
//////////////////////////Rain Particle 
//This is for the rain particle
var fft;
var smoothing = 0.8; // smoothing from 0 - 0.99
var binCount = 1024; // 16 - 1024
var particles =  new Array(binCount);

// Variable particle
var Particle = function(position) 
{
    this.position = position; //Position of particle
    this.scale = random(0, 1); //Scale of particle
    this.speed = createVector(0, random(0, 5) ); //Speed of particle
    this.colour = [random(0,255), 
                   random(0,255), 
                   random(0,255), 255]; //Colour of particle
}
    
    // Expansion
    var Expansion = 1;
    
    //Particle Update
    // Diameter, Speed adjusted by FFT bin level
    Particle.prototype.update = function(level) 
    {
        this.position.y += this.speed.y / (level*2); //position Y + speed Y
        
        if (this.position.y > height) 
        {
            this.position.y = 0;
        }
        
        //Diameter Mapping
        this.diameter = map(level, 0, 1, 0, 100) * this.scale * Expansion;
    }
    
    //Particle Draw
    Particle.prototype.draw = function() 
    {
        // PArticle Colour
        fill(this.colour[0] + Red_Colour,
             this.colour[1] + Green_Colour,
             this.colour[2] + Blue_Colour, 
             this.colour[3] - Alpha_Fill);
        
        //Particle Stroke
        stroke(this.colour[0] + Red_Colour,
             this.colour[1] + Green_Colour,
             this.colour[2] + Blue_Colour);
        
        //Particle StrokeWeight
        strokeWeight(StrokeSize);
        
        //LINE DEFORM
        if (Deform == 0) //Set to both Deforms for now
        {
            line(this.position.x, 
                this.position.y,
                this.position.x + 5 + ShapeSize, 
                this.position.y + 5 + ShapeSize);
            
            line(this.position.x + 5 + ShapeSize, 
                this.position.y,
                this.position.x, 
                this.position.y + 5 + ShapeSize);
        }
        
        //RECT DEFORM
        if (Deform == 1) //Set to both Deforms for now
        {
            rect(this.position.x - this.diameter/2, 
                this.position.y - this.diameter/2,
                this.diameter + ShapeSize, 
                this.diameter + ShapeSize);
        }
        
        //ELLIPSE DEFORM
        if (Deform == 2)
        {
            ellipse(this.position.x, 
                this.position.y, 
                this.diameter + ShapeSize, 
                this.diameter + ShapeSize);
        }
        
        //ROTATION adjusted by Seed
        rotate((1 + Velocity)/Seed);
    };
//////////////////////////////////////////////////////////////////////

function rainParticles()
{
    this.name = "Rain Particles"; //vis name
    //instantiate the fft object
    fourier = new p5.FFT(smoothing, binCount);
    
    // instantiate the Rain particles.
    ////////////////////////////////////////////////////////
    for (var i = 0; i < particles.length; i++) 
    {
        var x = map(i, 0, binCount, 0, width * 2); // X
        var y = random(0, height); // Y
        var position = createVector(x, y); // Variable position
        
        particles[i] = new Particle(position);
    } 
    
    this.draw = function() 
    {
        background(0); 
      
        push();
      
        if (Seed >= 1)
        {
            scale(0.5);
            translate(width,height);
        }
    
        //low to high freq returned by array
        var spectrum = fourier.analyze(binCount);

        // update and draw all [binCount] particles!
        // Each particle gets a level that corresponds to
        // the level at one bin of the FFT spectrum. 
        // This level is like amplitude, often called "energy."
        // It will be a number between 0-255.
        for (var i = 0; i < binCount; i++) 
        {
            var thisLevel = map(spectrum[i], 0, 255, 0, 1);

            // update values based on amplitude at this part of the frequency spectrum
            particles[i].update( thisLevel ); //UPDATE PARTICLES

            // draw the particle
            particles[i].draw(); //DRAW PARTICLES

            // update x position (in case we change the bin count while live coding)
            particles[i].position.x =
            map(i, 0, binCount, 0, windowWidth * 4 - 100); //POSITION PARTICLES
        }
        pop();
    }
}