function A2()
{
    this.name = "A2";
    var binCount256 = 256;
    fourier = new p5.FFT(smoothing, binCount256);
    
    this.draw = function() 
    {
        background(0);
        push();
        
        blendMode(ADD);
        blendMode(BLEND);
        noFill();
        var spectrum = fourier.analyze();

        translate(width / 2, height / 2);
                   strokeWeight(1 + StrokeSize);

        //Draw the pink radials changed by the spectrum of the music
        for(var i = 0; i < spectrum.length ; i++)
        {
            var angle = map(i, 0, spectrum.length, 0, 10);
            var amp = spectrum[i];
            var r = map(amp, 0, 256, 1, 600);
            var x = r* cos(angle);
            var y = r* sin(angle);
            
            stroke(random(255) + Red_Colour,
                   Green_Colour, 
                   Blue_Colour);
            
            if (Deform == 0)
            {
                line(0, 0, 
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 1)
            {
                rect(0 - (ShapeSize * 2)/2 ,
                     0 - (ShapeSize * 2)/2, 
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 2)
            {
                ellipse(0, 0,
                        x * 2 + ShapeSize * 2, 
                        y * 2 + ShapeSize * 2);
            }
        }
        
        //Draw the purple radials changed by the spectrum of the music
        for (var i = 0; i < spectrum.length; i++) 
        {
            var angle = map(i, 0, spectrum.length, 0, 10);
            var amp = spectrum[i];
            var r = map(amp, 0, 512, 1, 700);
            var x = r * cos(angle);
            var y = r * sin(angle);

            stroke(Red_Colour, 
                   random(255) + Green_Colour, 
                   Blue_Colour);
            
            if (Deform == 0)
            {
                line(0 , 0,
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 1)
            {
                rect(0 - (ShapeSize * 2)/2,
                     0 - (ShapeSize * 2)/2, 
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 2)
            {
                ellipse(0, 0,
                        x * 2 + ShapeSize * 2, 
                        y * 2 + ShapeSize * 2);
            }
        }
        
        //Draw the cyan radials changed by the spectrum of the music
        for(var i = 0; i < spectrum.length ; i++)
        {
            var angle = map(i, 0, spectrum.length, 0, 10);
            var amp = spectrum[i];
            var r = map(amp, 0, 1024, 1, 800);
            var x = r* cos(angle);
            var y = r* sin(angle);
            stroke(Red_Colour, 
                   Green_Colour, 
                   random(255) + Blue_Colour);
            
            if (Deform == 0)
            {
                line(0, 0,
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 1)
            {
                rect(0 - (ShapeSize * 2)/2,
                     0 - (ShapeSize * 2)/2, 
                     x + ShapeSize * 2, 
                     y + ShapeSize * 2);
            }
            
            if (Deform == 2)
            {
                ellipse(0, 0,
                        x * 2 + ShapeSize * 2, 
                        y * 2 + ShapeSize * 2);
            }
        }
        
        //Draw the ellipse at the back and changed by the spectrum of the music
        for (var i = 0; i < spectrum.length; i+=40) 
        {
            var angle = map(i, 0, spectrum.length, 0, 10);
            var amp = spectrum[i];
            var r = map(amp, 0, 64, 1, 25);
            
            fill(100 + Red_Colour, 
                 Green_Colour, 
                 Blue_Colour, 
                 255 - Alpha_Fill);
            
            stroke(255 + Red_Colour, 
                   Green_Colour, 
                   Blue_Colour,
                   255 - Alpha_Fill);
            
            strokeWeight(r * cos(angle) + StrokeSize);
            ellipseMode(CENTER);
            ellipse(0, 0, 
                    r + ShapeSize * 2, 
                    r + ShapeSize * 2);

        }
        pop();
    }
}