function Waves()
{
    this.name = "Waves";
    var ranges;
    this.frequencyBins = ["bass", "lowMid", "highMid", "treble"];
    
    this.draw = function()
    {
        push();
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energyTreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        
        background(0);
        
        blendMode(ADD);
        blendMode(BLEND);
        noFill();
        strokeWeight(StrokeSize + energyTreb/100);
        
        ranges = 2 + energyBass/10;
        for (var i = 0; i < ranges; i++) 
        {
            var paintRed = 
            map(i, 0, ranges, 0, random(0,255));
            var paintGreen = 
            map(i, 0, ranges, 0, random(0,255));
            var paintBlue = 
            map(i, 0, ranges, 0, random(0,255));
            stroke(paintRed + Red_Colour,
                   paintGreen + Green_Colour,
                   paintBlue + Blue_Colour,
                  255 - Alpha_Fill);

            beginShape();
            for (var x = 0; x < windowWidth; x += 20) 
            {
                var n = noise(x * 0.001, i * 0.01, 
                        frameCount * 0.02 + energyBass * 0.02);
                var y = map(n, 0, 1, 0,height);

                if (Deform == 0)
                {
                    curveVertex(x,y);
                }

                if (Deform == 1)
                {
                    noFill();
                    rect(x - (2 + ShapeSize)/2,
                         y - (2 + ShapeSize)/2,
                         2 + ShapeSize,
                         2 + ShapeSize);
                }

                if (Deform == 2)
                {
                    point(x,y);
                }    
            }
            endShape();
        }
        pop();
    }
}