//SPECTRUM EXTENSION - EXAMPLE 1
function vertexChord()
{
	this.name = "Vertex Chord";
    
    this.frequencyBins = ["bass", 
                          "lowMid", 
                          "highMid", 
                          "treble"];
    
    var t = 0;
    
	this.draw = function()
    {
        background(0);
        
        push(); //<-- so it doesnt affect the other visualistaions
        
        blendMode(BLEND);
        blendMode(ADD);
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        
        translate(width/2,height/2 - 100);
        
        //loop for adding lines
        for(var i = 0; i < 1 + energytreb; i++)
        {
            stroke(Red_Colour + random(0,255),
                   Green_Colour + random(0,255),
                   Blue_Colour + random(0,255));
            
            strokeWeight(StrokeSize);
            noFill();
            
            if (Deform == 0)
            {
                line(this.x1(t+i + Seed) - energyHigh,
                     this.y1(t+i + Seed) + energyLow,
                     this.x2(t+i) + (ShapeSize * 2) + energyBass,
                     this.y2(t+i) + (ShapeSize * 2) - energytreb);
            }
            
            if (Deform == 1)
            {
                rect(this.x1(t+i + Seed) - energyHigh,
                     this.y1(t+i + Seed) + energyLow,
                     this.x2(t+i) + (ShapeSize * 2) + energyBass,
                     this.y2(t+i) + (ShapeSize * 2) - energytreb);
            }
            
            if (Deform == 2)
            {
                ellipse(this.x1(t+i + Seed) - energyHigh,
                        this.y1(t+i + Seed) + energyLow,
                        this.x2(t+i) + (ShapeSize * 2) + energyBass,
                        this.y2(t+i) + (ShapeSize * 2) - energytreb);
            }
        }
            t+= 1 + energytreb/100; 
     
		pop();
	};
    
    // function to change initial x co-ordinate of the line
    this.x1 = function(t)
    {
        return cos(t/20 + Seed) * 125 + 
                sin(t/30 + Seed) * 12.5 + 
                cos(t/40 + Seed) * 125;
    }

    // function to change initial y co-ordinate of the line
    this.y1 = function(t)
    {
        return sin(t/10 + Seed) * 125 + 
                cos(t/20 + Seed) * 12.5 + 
                sin(t/30 + Seed) * 125;
    }

    // function to change final x co-ordinate of the line
    this.x2 = function(t)
    {
        return cos(t/20 + Seed) * 125 + 
                sin(t/30 + Seed) * 12.5 + 
                cos(t/40 + Seed) * 125;
    }

    // function to change final y co-ordinate of the line
    this.y2 = function(t)
    { 
        return sin(t/10 + Seed) * 125 + 
                cos(t/20 + Seed) * 12.5 + 
                sin(t/30 + Seed) * 125;
    }
}
////////
