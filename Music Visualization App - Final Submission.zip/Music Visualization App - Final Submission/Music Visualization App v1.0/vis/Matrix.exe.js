let font1;
let cols = [];
let NUMCOLS = 150;
let t = 0;
let dt = 0.1;
let GREEN;
let WHITE;
//Frequency Bins
var frequencyBins = ["bass", "lowMid", "highMid", "treble"];

function Matrix() 
{
    this.name = "The Matrix";
    
	textSize(24);
	for (let c=0; c<NUMCOLS; c++)
    {
		cols.push(new Column());
	}
    
    this.draw = function() 
    {
        push();
        
        background(Red_Colour/2,
                   Green_Colour/2,
                   Blue_Colour/2);
        
        fill(0,200,0);
        for (let k=0;k<cols.length;k++)
        {
            cols[k].update();
        }
        pop();
    }
}

class Column
{
	constructor()
    {
		this.x = random(1,1999);
		this.y = random(-300,height);
		this.sz = 20;
		this.vel = random(1,5);
		this.symbols = [];
		this.column_length = random(10,20);
		for (let b = 0;b<this.column_length;b++)
        {
            this.symbols.push(String.fromCharCode(0x03080 + round(random(0,42))));
		}
	}
	
	update()
    {
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(frequencyBins[0]); //ENERGY BASS initialisation
        energyBass = energyBass/1024 * 255;
        var energyLow = fourier.getEnergy(frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(frequencyBins[3]); 
        energytreb = energytreb/1024 * 255;
        //ENERGY Treble initialisation
        
        this.y += this.vel;
        //replace random character in column

        //draw characters in place
        for (let a = 0;a<this.column_length;a++)
        {
            // if it goes off screen, reset to top
            if (this.y > height+70)
            {
                this.y = 0;
            }
            
            var spectrum = fourier.analyze(); //Spectrum Analysed
            var energyBass = fourier.getEnergy(frequencyBins[0]); //ENERGY BASS initialisation
            var energyLow = fourier.getEnergy(frequencyBins[1]); //ENERGY Low initialisation
            var energyHigh = fourier.getEnergy(frequencyBins[2]); //ENERGY High initialisation
            var energytreb = fourier.getEnergy(frequencyBins[3]); 
            
            GREEN = color(0,energyBass,0);
            WHITE = color(energytreb,energyHigh,energyLow);
            
            if ((a === 0) && 
                 random(100) < 10)
            { 
                fill(WHITE);
            } 

            else 
            {
                fill(GREEN);
            }
            textAlign(CENTER, TOP);

            if (random(100) < 20)
            {
                this.symbols[a] = String.fromCharCode(0x03080 + round(random(0,42)));
            }
            stroke(energytreb/102.4 * 255);
            text(this.symbols[a],this.x,this.y-this.sz*a);
        }
	}
}
