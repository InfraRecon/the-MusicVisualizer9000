//EXTENSION 2
//draw the hologram to the screen
function Hologram() {
	//vis name
	this.name = "Holo Mesh";

	//draw the hologram to the screen
	this.draw = function() 
    {
        background(0);
        push();
        
        scale(0.5); // SCALER
        translate(width,height); //Translater...for position
        noFill();
        
        //SPECTRUM , Colour, Size LOOP
        var spectrum = fourier.analyze();
        for (var i = 0; i < spectrum.length; i++)
        {   
            var red = map(spectrum[i + Red_Colour], 0, 255, 255, 0); //r
            var green = map(spectrum[i + Green_Colour], 0, 255, 255, 0); //g
            var blue = map(spectrum[i + Blue_Colour], 0, 255, 255, 0); //b
            var alpha = spectrum[i + Alpha_Fill]; //Alpha
            
            //Stroke ,Stroke Weight
            stroke(red,green,blue,alpha);
            strokeWeight(StrokeSize);
            
            //Size
            var sizeSpectrum = -height + 
            map(spectrum[i],0,255,height/spectrum[i],width/2);
            
            if (Deform == 0)
            {
                line(0,0, 
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10,
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10); 
            }
            
            if (Deform == 1)
            {
                rect(0 - (sizeSpectrum/i + spectrum[i] * ShapeSize/10)/2,
                     0 - (sizeSpectrum/i + spectrum[i] * ShapeSize/10)/2, 
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10,
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10); 
            }
            
            if (Deform == 2)
            {
                if (Seed > 2)
                {
                    Seed = 2;    
                }
                
                ellipse(0,0, 
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10,
                    sizeSpectrum/i + spectrum[i] * ShapeSize/10); 
            }
            
            
            //Rotation
            rotate(PI/Seed);
            
            //Visualization DEFORMS
            //LINE DEFORM
            if (Deform == 0)
            {
                line(width/2,
                    height/2 -spectrum[i] 
                     * spectrum.length/height,
                    sizeSpectrum,
                    sizeSpectrum); 
            }
            
            //RECT DEFORM
            if (Deform == 1)
            {
                rect(width/2,
                    height/2 -spectrum[i] 
                     * spectrum.length/height,
                    sizeSpectrum,
                    sizeSpectrum); 
            }
            
            //ELLIPSE DEFORM
            if (Deform == 2)
            {
                if (Seed > 2)
                {
                    Seed = 2;    
                }
                
                ellipse(width/2,
                    height/2 -spectrum[i] 
                        * spectrum.length/height,
                    sizeSpectrum,
                    sizeSpectrum); 
            }
        }
        pop();
	}
};
/////////