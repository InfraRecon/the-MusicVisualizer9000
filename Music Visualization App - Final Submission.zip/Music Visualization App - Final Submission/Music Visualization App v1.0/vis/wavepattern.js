//WAVE FORM EXTENSION - EXAMPLE 2 (I made some IMPROVEMENTS)
//draw the waveform to the screen
function WavePattern() {
	//vis name
	this.name = "Sound Waves";
	//draw the wave form to the screen
    
    //WAVE PATTERN DRAW
	this.draw = function() 
    {
        background(0); 
        
        //RGB COLOURS
        var Red = Red_Colour;
        var Green = Green_Colour;
        var Blue = Blue_Colour;
        var Alpha = 255 - Alpha_Fill;
        
		push();
        
        blendMode(ADD);
        blendMode(BLEND);
        
		noFill();
		stroke(random(0,255) + Red_Colour,
               random(0,255) + Green_Colour, 
               random(0,255) + Blue_Colour,
               255 - Alpha_Fill)
		strokeWeight(StrokeSize);

		beginShape(); //BEGIN SHAPE
		//calculate the waveform from the fft.
		var wave = fourier.waveform();
        
		for (var i = 0; i < wave.length; i++) 
        {
			//for each element of the waveform map it to screen
			//coordinates and make a new vertex at the point.
			var x = map(i, 0, wave.length, 0, width);
			var y = map(wave[i], -1, 1, 0, height);
            
            //VIS DEFORM
            //CURVE DEFORM
            if (Deform == 0)
            {
                curveVertex(x, y);
            }
            
            //RECT DEFORM
            if (Deform == 1)
            {
                rect(x, y,
                     ShapeSize,
                     ShapeSize);  
            }
            
            //ELLIPSE DEFORM
            if (Deform == 2)
            {
                ellipse(x, y,
                        ShapeSize,
                        ShapeSize);  
            }
		}

		endShape(); //END SHAPE
		pop();
	};
}