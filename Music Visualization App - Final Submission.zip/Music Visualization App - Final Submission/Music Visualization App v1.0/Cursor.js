//Cursor Particle Variables
////////////////////////////////////////////////////////////
const MAX_TRAIL_COUNT = 10;

var colorScheme = ["#0A1B28", "#071F43", "#357D7E", "#35EEEE", "#919DF0"];

var trail = [];
var cursorParticles = [];
////////////////////////////////////////////////////////////
function Cursor()
{
    this.frequencyBins = ["bass", "lowMid", "highMid", "treble"];
    
    this.draw =function()
    {
        push();
        blendMode(BLEND);
        blendMode(SCREEN);
        blendMode(ADD);
        
        var spectrum = fourier.analyze(); //Spectrum Analysed
    
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        energyBass = energyBass/1024 * 255;
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        energyLow = energyLow/1024 * 255;
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        energyHigh = energyHigh/1024 * 255;
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treble initialisation
        energytreb = energytreb/1024 * 255;
        
        if (CParticles)
        {
            // Trim end of trail.
            trail.push([mouseX, mouseY]);

            let removeCount = 1;
            if (mouseIsPressed && 
                mouseButton == CENTER) 
            {
                removeCount++;
            }

            for (let i = 0; i < removeCount; i++) 
            {
                if (trail.length == 0) 
                {
                    break;
                }

                if (mouseIsPressed || trail.length > MAX_TRAIL_COUNT) 
                {
                    trail.splice(0, 1);
                }
            }

            // Spawn particles.
            if (trail.length > 1) {
                let mouse = new p5.Vector(mouseX, mouseY);
                mouse.sub(pmouseX + random(-energytreb/5,
                                           energytreb/5), 
                          pmouseY + random(-energytreb/5,
                                           energytreb/5));
                if (mouse.mag() > 5) 
                {
                    mouse.normalize();
                    for (let i = 0; i < 3; i++) 
                    {
                        cursorParticles.push(new cursorParticle(pmouseX, 
                                                                pmouseY, 
                                                                mouse.x, 
                                                                mouse.y));
                    }
                }
            }

            // Move and kill particles.
            for (let i = cursorParticles.length - 1; i > -1; i--) 
            {
                cursorParticles[i].move();
                if (cursorParticles[i].vel.mag() < 0.1) 
                {
                    cursorParticles.splice(i, 1);
                }
            }

            // Draw trail.
            drawingContext.shadowColor = color(energyBass,
                                               energyLow,
                                               energyHigh,255- energytreb);

            for (let i = 0; i < trail.length; i++) 
            {
                let mass = i * 1.5;
                drawingContext.shadowBlur = mass;

                stroke(0);
                strokeWeight(mass);
                point(trail[i][0], trail[i][1]);
            }

            // Draw particles.
            for (let i = 0; i < cursorParticles.length; i++) 
            {
                let p = cursorParticles[i];
                let mass = p.mass * p.vel.mag() * 0.6;

                drawingContext.shadowColor = color(colorScheme[p.colorIndex]);
                drawingContext.shadowBlur = mass;

                stroke(0);
                strokeWeight(mass);
                point(p.pos.x, p.pos.y);

                stroke(255);
                strokeWeight(mass * 0.05);
                point(p.pos.x, p.pos.y);
            }
        }
        pop();
    }
}