//MUSIC BAR FEATURE
function songBar()
{
    //DRAW SONG BAR
    this.draw = function()
    {
        //Song Duration, Current Time Intialisation
        soundlength = sound.duration();
        minutes = floor(soundlength / 60) - 
                  floor(floor(soundlength / 60) / 60) * 60;
        seconds = round(soundlength - floor(soundlength / 60) * 60);
        hours = floor((soundlength/60)/60);
        
        push();
        //When the mouse is in range the bar will translate, Not entirly Ideal 
        translate(0,200);
        if (dist(mouseX,
                 mouseX, 
                 width,
                 width) > 0 &&
            dist(mouseY,
                 mouseY, 
                 height/1.01,
                 height/1.01) < 200 &&
            menu != true ||
            lock)
        {
            translate(0,-200);
        }
        
        //Songs Current Time
        songCurrentTime = sound.currentTime();
        
        if(songCurrentTime > 0)
        {
            songCurrentTimetemp = songCurrentTime;
        }

        stroke(100);
        strokeWeight(1);
        fill(100);
        rect(width/3 * width/width,
             height - 46/height * height,
             width/2.9 * width/width,
             5,5);

        fill(randomR,
             randomG,
             randomB);
        noStroke();
        rect(width/3 + 1 * width/width,
             height - 43.5/height * height,
             songCurrentTimetemp/soundlength * width/2.9 * width/width,
             2,5);
        
        currentHours = floor((songCurrentTimetemp/60)/60);
        currentMinutes = floor(songCurrentTimetemp / 60) - 
                         floor(floor(songCurrentTimetemp / 60) / 60) * 60;
        currentSeconds = round(songCurrentTimetemp - 
                         floor(songCurrentTimetemp / 60) * 60);

        //Song Time
        fill(255);
        noStroke();
        textSize(12);

        //Drw Text current time
        //Hours
        if (currentHours >= 1)
        {
            text(currentHours + " h :" + 
                 currentMinutes + " m :" + 
                 currentSeconds + "'s", 
                 width/3 - 80 * width / width,
                 height - 39 * height / height);
        }
        // Minutes, No hours
        else
        {
            text(currentMinutes + " m :" + 
                 currentSeconds + "'s", 
                 width/3 - 55 * width / width,
                 height - 39 * height / height);
        }

        //Draw Text Total Time
        //Hours
        if (hours >= 1)
        {
            text(hours + " h :" + 
                 minutes + " m :" + 
                 seconds + "'s", 
                 width/1.44 / width * width,
                 height - 39 * height / height);
        }
        //Minutes, No Hours
        else
        {
            text(minutes + " m :" + 
                 seconds + "'s", 
                 width/1.46 / width * width,
                 height - 39 * height / height);
        }
        
        //Text Size Adjuster
        textSize(20);
        
        if(mic)
        {
            if (sound.isPlaying())
            {
                text("Playing: " + songName, 
                     160  / width * width,
                     height - 120 * height / height);   
            }
            else if (sound.isPaused())
            {
                 text("Paused: " + songName, 
                      160  / width * width,
                      height - 120 * height / height); 
            }
            else
            {
                text("Selected Song: " + songName, 
                     160  / width * width,
                     height - 120 * height / height); 
            }
        }
        
        if (!mic)
        {
            text("MICROPHONE LISTENING", 
                 160  / width * width,
                 height - 120 * height / height);
        }
        
        pop(); 
    }
}
///////