//Blob Variables
var step;
var n = 30; // number of blobs
var radius = 5; // diameter of the circle
var inter = 1; // difference between the sizes of two blobs
var maxNoise = 3000;
var noiseProg = (x) => (x*x);

function StartMenu()
{
    this.draw = function()
    {
        push();
        if (startMenu && 
            !loadingS && 
            !about)
        {   
            //Blob Visualization
            fill(randomR,
                 randomG,
                 randomB);
            rect(0,0,windowWidth,windowHeight);
            
            //Blob Variables
            step;
            n = 50; // number of blobs
            radius = 2; // diameter of the circle
            inter = 1; // difference between the sizes of two blobs
            maxNoise = width;
            noiseProg = (x) => (x*x);
            step = 0.01;
            
            var t = frameCount/250;
            kMax = noise(t/2);
            frameCount = 0;
            
            //First Blob
            noStroke();
            for (var i = n; i >= 0; i--) 
            {
                var alpha = 1 - noiseProg(i / n);
                fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                var size = radius + i * inter;
                var k = kMax * sqrt(i/n);
                var noisiness = maxNoise * noiseProg(i / n);
                blob(size, 0, 0, k, t + i * step, noisiness);
            }
            
            //Second Blob
            noStroke();
            for (var i = n; i >= 0; i--) 
            {
                var alpha = 1 - noiseProg(i / n);
                fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                var size = radius + i * inter;
                var k = kMax * sqrt(i/n);
                var noisiness = maxNoise * noiseProg(i / n);
                blob(size, windowWidth, windowHeight, k, t + i * step, noisiness);
            }

            //Star Menu Shapes
            fill(randomR + 10,
                 randomG + 10,
                 randomB + 10,75);

            stroke(0);

            //Start
            if (mouseX > width/2 - 305 &&
                mouseX < width/2 - 5 &&
                mouseY > height/2 - 305 &&
                mouseY < height/2 - 5 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 295 + 310 * 0 + mouseX/width * 10,
                     height/2 - 295 + 310 * 0 + mouseY/height * 10,
                     290,290);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + 310 * 0 + mouseX/width * 10,
                     height/2 - 300 + 310 * 0 + mouseY/height * 10,
                     300,300); 
            }
            
            fill(randomR + 15,
                 randomG + 15,
                 randomB + 15,75);
            //Music
            if (mouseX > width/2 + 5 &&
                mouseX < width/2 + 305 &&
                mouseY > height/2 - 305 &&
                mouseY < height/2 - 5 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 295 + 310 * 1 + mouseX/width * 10,
                     height/2 - 295 + 310 * 0 + mouseY/height * 10,
                     290,290);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + 310 * 1 + mouseX/width * 10,
                     height/2 - 300 + 310 * 0 + mouseY/height * 10,
                     300,300);
            }
            
            fill(randomR + 20,
                 randomG + 20,
                 randomB + 20,75);
            //Menu
            if (mouseX > width/2 - 305 &&
                mouseX < width/2 - 5 &&
                mouseY > height/2 + 5 &&
                mouseY < height/2 + 305 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 295 + 310 * 0 + mouseX/width * 10,
                     height/2 - 295 + 310 * 1 + mouseY/height * 10,
                     290,290);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + 310 * 0 + mouseX/width * 10,
                     height/2 - 300 + 310 * 1 + mouseY/height * 10,
                     300,300);
            }
            
            fill(randomR + 25,
                 randomG + 25,
                 randomB + 25,75);
            //About
            if (mouseX > width/2 + 5 &&
                mouseX < width/2 + 305 &&
                mouseY > height/2 + 5 &&
                mouseY < height/2 + 305 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 295 + 310 * 1 + mouseX/width * 10,
                     height/2 - 295 + 310 * 1 + mouseY/height * 10,
                     290,290);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + 310 * 1 + mouseX/width * 10,
                     height/2 - 300 + 310 * 1 + mouseY/height * 10,
                     300,300);
            }
            
            fill(randomR + 30,
                 randomG + 30,
                 randomB + 30,75);
            //other
            //Notes
            if (mouseX > 25 + mouseX/width * 10 &&
                mouseX < width/2 - 310 + mouseX/width * 10 &&
                mouseY > height/2 - 300 + mouseY/height * 10 &&
                mouseY < height/2 - 300 + height/2 + 310 - 50 + mouseY/height * 10 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(30 + mouseX/width * 10, 
                     height/2 - 295 + mouseY/height * 10,
                     width/2 - 330 - 15,
                     height/2 + 300 - 50);
                
                fill(255);
                stroke(0);
                textSize(30);
                textFont("Fugaz One");
                strokeWeight(3);
                text("Welcome to the Music Visualizer 9000",
                        35 + mouseX/width * 10,
                        height/2 - 200 + mouseY/height * 10,width - 1200);

                text("Check out the Tutorial for some information about the main features",
                        35 + mouseX/width * 10,
                        height/2 - 100 + mouseY/height * 10,width - 1400);

                text("The final version of the music visualization app (v1.0)",
                        35 + mouseX/width * 10,
                        height - 100 + mouseY/height * 10,width - 1400);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(25 + mouseX/width * 10, 
                     height/2 - 300 + mouseY/height * 10,
                     width/2 - 320 - 15,
                     height/2 + 310 - 50);
                
                    image(NotepadIMG,
                          25 + (width/2 - 320 - 15 - 100)/2 + mouseX/width * 10, 
                          height/2 + 50 + mouseY/height * 10,100,100);
            }
            
            fill(randomR + 35,
                 randomG + 35,
                 randomB + 35,75);
            //Mods
            if (mouseX > width/2 + 320 + mouseX/width * 10 &&
                mouseX < width - 50 + mouseX/width * 10 &&
                mouseY > height/2 - 300 + mouseY/height * 10 &&
                mouseY < height/2 - 300 + 610 + mouseY/height * 10 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 + 325 + mouseX/width * 10, 
                     height/2 - 295 + mouseY/height * 10,
                     width/2 - 330 - 50,
                     600);
                
                fill(255);
                stroke(0);
                textSize(30);
                textFont("Fugaz One");
                strokeWeight(3);
                text("Adjust Visualizations visuals", 
                     width/2 + 330 + mouseX/width * 10,
                     height/2 - 200 + mouseY/height * 10,width - 800);
                
                text("Adjust Shapes, RGB values and more", 
                     width/2 + 330 + mouseX/width * 10,
                     height/2 - 140 + mouseY/height * 10,width - 800);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 + 320 + mouseX/width * 10, 
                     height/2 - 300 + mouseY/height * 10,
                     width/2 - 320 - 50,
                     610); 
                                
                image(ModIMG,                     
                        width/2 + 320 + (width/2 - 320 - 50 - 100)/2  + mouseX/width * 10,
                        height/2 - 50 + mouseY/height * 10,100,100);
            }

            fill(randomR + 40,
                 randomG + 40,
                 randomB + 40,75);
            //Tutorial
            if (mouseX > width/2 - 300 + mouseX/width * 10 &&
                mouseX < width - 50 + mouseX/width * 10 &&
                mouseY > 25 + mouseY/height * 10 &&
                mouseY < height/2 - 320 + mouseY/height * 10 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 295 + mouseX/width * 10, 
                     30 + mouseY/height * 10,
                     width - width/2 + 255 - 15,
                     height/2 - 345);
                
                fill(255);
                stroke(0);
                textSize(30);
                textFont("Fugaz One");
                strokeWeight(3);
                text("Some Information about the features and how the program works", 
                     width/2 - 290 + mouseX/width * 10,
                     125 + mouseY/height * 10,width - 300);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + mouseX/width * 10, 
                     25 + mouseY/height * 10,
                     width - width/2 + 265 - 15,
                     height/2 - 335);
                
                image(TutorialIMG,
                      width/2 - 300 + (width - width/2 + 265 - 15 - 100)/2 + mouseX/width * 10, 
                      25 + (height/2 - 335 - 150)/2 + mouseY/height * 10,100,120);
            }
            
            fill(randomR + 45,
                 randomG + 45,
                 randomB + 45,75);
            //settings
            if (mouseX > width/2 - 300 + mouseX/width * 10 &&
                mouseX < width/2 - 300 + 610 + mouseX/width * 10 &&
                mouseY > height/2 + 320 + mouseY/height * 10 &&
                mouseY < height - 50 + mouseY/height * 10 &&
                startMenu)
            {
                stroke(randomR,randomG,randomB);
                strokeWeight(1);
                rect(width/2 - 295 + mouseX/width * 10, 
                     height/2 + 325 + mouseY/height * 10,
                     600,
                     height/2 - 370);
                
                fill(255);
                stroke(0);
                textSize(30);
                textFont("Fugaz One");
                strokeWeight(3);
                text("Adjust screen settings and effects", 
                     width/2 - 290 + mouseX/width * 10,
                    height/2 + 420 + mouseY/height * 10,width - 300);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 - 300 + mouseX/width * 10, 
                     height/2 + 320 + mouseY/height * 10,
                     610,
                     height/2 - 360);
                
                image(SettingsIMG,
                      width/2 - 50 + mouseX/width * 10,
                      height/2 + 270 + (height/2 - 360)/2 + mouseY/height * 10,100,100);
            }
            
            fill(randomR + 50,
                 randomG + 50,
                 randomB + 50,75);           
            //Legacy visualizations
            if (mouseX > width/2 + 320 + mouseX/width * 10 &&
                mouseX < width - 50 + mouseX/width * 10 &&
                mouseY > height/2 + 320 + mouseY/height * 10 &&
                mouseY < height - 50 + mouseY/height * 10 &&
                startMenu)
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 + 325 + mouseX/width * 10, 
                     height/2 + 325 + mouseY/height * 10,
                     width - width/2 - 330 - 50,
                     height/2 - 370);
                
                fill(255);
                stroke(0);
                textSize(30);
                textFont("Fugaz One");
                strokeWeight(3);
                text("Check out creator inspired visualizations",
                     width/2 + 332 + mouseX/width * 10,
                    height/2 + 420 + mouseY/height * 10,width - 1000);
            }
            else
            {
                stroke(randomR,
                       randomG,
                       randomB);
                strokeWeight(1);
                rect(width/2 + 320 + mouseX/width * 10, 
                     height/2 + 320 + mouseY/height * 10,
                     width - width/2 - 320 - 50,
                     height/2 - 360);
                
                image(LegacyIMG,
                        width/2 + 320 + (width - width/2 - 320 - 50 - 115)/2 + mouseX/width * 10, 
                        height/2 + 325 + (height/2 - 360 - 95)/2 + mouseY/height * 10,
                        110,100);
            }

            //Start Menu Text
            textFont("Harlow Solid");
            noStroke();

            textSize(100);
            fill(255);
            strokeWeight(5);
            stroke(0);
            text("M",50,120);
            text("V",100,190);

            textSize(100);
            if (sound.isPlaying() ||
                sound.isPaused())
            {
                textSize(85);
                text("Resume", 
                    width/2 - 290 + mouseX/width * 10,
                    height/2 - 120 + mouseY/height * 10);
                textSize(100);
            }
            else
            {
                text("Start", 
                     width/2 - 265 + mouseX/width * 10,
                     height/2 - 120 + mouseY/height * 10); 
            }

            text("Music", 
                 width/2 + 30 + mouseX/width * 10,
                 height/2 - 120 + mouseY/height * 10);

            text("Menu", 
                 width/2 - 270 + mouseX/width * 10,
                 height/2 + 190 + mouseY/height * 10);

            text("About", 
                 width/2 + 25 + mouseX/width * 10,
                 height/2 + 190 + mouseY/height * 10);

            textSize(45);
            text("Notes", 
                 35 + mouseX/width * 10,
                 height/2 - 260 + mouseY/height * 10);
            
            textSize(45);
            textFont("Harlow Solid");
            strokeWeight(5);
            text("Mods", 
                 width/2 + 330 + mouseX/width * 10,
                 height/2 - 260 + mouseY/height * 10);

            text("Tutorial", 
                 width/2 - 290 + mouseX/width * 10,
                 65 + mouseY/height * 10);
            
            textFont("Harlow Solid");
            text("Legacy Visulizations", 
                 width/2 + 332 + mouseX/width * 10,
                 height/2 + 360 + mouseY/height * 10,width - 500);

            text("Settings", 
                 width/2 - 290 + mouseX/width * 10,
                 height/2 + 360 + mouseY/height * 10);
            
            
            stroke(0);
            strokeWeight(2);
            if(sound.isPlaying())
            {
                rect(170,55,15,50);
                rect(205,55,15,50); 
            }
            else if (sound.isPaused())
            {
                triangle(200 - 25, 80 - 25,
                     200 + 25, 80,
                     200 - 25, 80 + 25);
            }
        }
        pop();
    }
}

//blob Shape Function
function blob(size, xCenter, yCenter, k, t, noisiness) 
{
    angleMode(DEGREES);
    beginShape();
    var angleStep = 360 / 50;
    for (var theta = 0; theta <= 360; theta += angleStep) 
    {
        var r1, r2;
            r1 = cos(theta)+1;
            r2 = sin(theta)+1;
        var r = size + noise(k * r1,  k * r2, t) * noisiness;
        var x = xCenter + r * cos(theta);
        var y = yCenter + r * sin(theta);
        curveVertex(x, y);
    }
    endShape(CLOSE);
    angleMode(RADIANS);
}

// After https://observablehq.com/@mbostock/sinebow
function interpolateSinebow(t, alpha) 
{
    angleMode(RADIANS);
    t = 0.5 - t;
    return color(
    255 * pow(sin(PI * (t + 0 / 3)), 2),
    255 * pow(sin(PI * (t + 1 / 3)), 2),
    255 * pow(sin(PI * (t + 2 / 3)), 2),
        alpha
    );
}