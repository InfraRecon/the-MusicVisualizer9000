//PLAYBACK BUTTON WITH ALL MOUSE INTERACTIONS
//displays and handles clicks on the playback button.
function PlaybackButton()
{
	//flag to determine whether to play or pause after button click and
	//to determine which icon to draw
    //Global
    settings = false;
    menu = false;
    mic = true;
    lock = false;
    fullColour = 
    color(randomR,
          randomG,
          randomB);
    
    //Local
    this.advance = false;
    this.previous = false; 
	this.playing = false;
    this.looping = false;
    this.volume = false;
    
    this.myMusic = false;
    this.info = false;
    this.legacy = false;
    this.quickMenu = false;
    this.visualiZationMods = false;
    var previousVolume;
    var gotSound;
    
    //SLIDERS
    //MIN and MAX Values for sound
    var minSoundValue = 0;
    var maxSoundValue = 100;
    this.sliderSound = 
    createSlider(minSoundValue, 
                 maxSoundValue, 25);
    this.sliderSound.style('width', '100px');
    this.sliderSound.style('height','5px');
    
    //MIN and MAX Values for Speed
    var minSpeedValue = -4;
    var maxSpeedValue = 5;
    this.sliderSpeed = 
    createSlider(minSpeedValue, 
                 maxSpeedValue, 1);
    this.sliderSpeed.style('width', '100px');
    this.sliderSpeed.style('height','5px');
    
    //VisualiZation Mods
    //MIN and MAX Values for Shape
    var minShapeValue = 0;
    var maxShapeValue = 2;
    this.sliderShape = 
    createSlider(minShapeValue, 
                 maxShapeValue, 0);
    this.sliderShape.style('width', '50px');
    this.sliderShape.style('height', '20px');
    
    //MIN and MAX Values for Shape Size
    var minShapeSizeValue = 0;
    var maxShapeSizeValue = 50;
    this.sliderShapeSize = 
    createSlider(minShapeSizeValue, 
                 maxShapeSizeValue, 10);
    this.sliderShapeSize.style('width', '50px');
    this.sliderShapeSize.style('height', '20px');
    
    //MIN and MAX Values for Random Seed
    var minRandomSeedValue = 0;
    var maxRandomSSeedValue = 50;
    this.sliderRandomSeed = 
    createSlider(minRandomSeedValue, 
                 maxRandomSSeedValue, 0);
    this.sliderRandomSeed.style('width', '50px');
    this.sliderRandomSeed.style('height', '20px');
    
    //MIN and MAX Values for Velocity
    var minVelocityValue = 0;
    var maxVelocityValue = 10;
    this.sliderVelocity = 
    createSlider(minVelocityValue, 
                 maxVelocityValue, 5);
    this.sliderVelocity.style('width', '50px');
    this.sliderVelocity.style('height', '20px');
    
    //MIN and MAX Values for Color
    var minColorValue = 0;
    var maxColorValue = 255;
    this.sliderColorRed = 
    createSlider(minColorValue, 
                 maxColorValue, 0);
    this.sliderColorRed.style('width', '50px');
    this.sliderColorRed.style('height', '5px');
    
    this.sliderColorGreen = 
    createSlider(minColorValue, 
                 maxColorValue, 0);
    this.sliderColorGreen.style('width', '50px');
    this.sliderColorGreen.style('height', '5px');
    
    this.sliderColorBlue = 
    createSlider(minColorValue, 
                 maxColorValue, 0);
    this.sliderColorBlue.style('width', '50px');
    this.sliderColorBlue.style('height', '5px');
    
    this.sliderColorAlpha = 
    createSlider(minColorValue, 
                 maxColorValue, 0);
    this.sliderColorAlpha.style('width', '50px');
    this.sliderColorAlpha.style('height', '5px');

    //MIN and MAX Values for Division
    var minDivisionValue = 0;
    var maxDivisionValue = 10;
    this.sliderDivision = 
    createSlider(minDivisionValue, 
                 maxDivisionValue, 5);
    this.sliderDivision.style('width', '50px');
    this.sliderDivision.style('height', '20px');
    
    //MIN and MAX Values for Stroke Size
    var minStrokeValue = 0;
    var maxStrokeValue = 20;
    this.sliderStrokeSize =
    createSlider(minStrokeValue,
                 maxStrokeValue, 2);
    this.sliderStrokeSize.style('width', '50px');
    this.sliderStrokeSize.style('height', '20px');
    
    //MIN and MAX Values for Stroke Size
    var minRandomSpaceImageValue = 1;
    var maxRandomSpaceImageValue = 5;
    this.sliderRandomSpaceImage = 
    createSlider(minRandomSpaceImageValue, 
                 maxRandomSpaceImageValue, 1);
    this.sliderRandomSpaceImage.style('width', '50px');
    this.sliderRandomSpaceImage.style('height', '20px');
    
    //MIN and MAX Values for Stroke Size
    var minRandomVehicleValue = 1;
    var maxRandomVehicleValue = 3;
    this.sliderRandomVehicle = 
    createSlider(minRandomVehicleValue,
                 maxRandomVehicleValue, 1);
    this.sliderRandomVehicle.style('width', '50px');
    this.sliderRandomVehicle.style('height', '20px');
    
    ////
    
    //MIN and MAX Values for Legacy Visulizations
    var minVisValue = 0;
    var maxVisValue = 8;
    this.sliderVis = 
    createSlider(minVisValue, 
                 maxVisValue, 0);
    this.sliderVis.style('width', '250px');
    this.sliderVis.style('height', '20px');
    
    //MIN and MAX Values for Filters
    var minFilterValue = 1;
    var maxFilterValue = 3;
    this.sliderFilter = 
    createSlider(minFilterValue, 
                 maxFilterValue, 1);
    this.sliderFilter.style('width', '50px');
    this.sliderFilter.style('height', '20px');
    
    //MIN and MAX Values for Cursors
    var minCursorValue = 1;
    var maxCursorValue = 4;
    this.sliderCursor = 
    createSlider(minCursorValue, 
                 maxCursorValue, 1);
    this.sliderCursor.style('width', '50px');
    this.sliderCursor.style('height', '20px');
    
    //MIN and MAX Values for Cursors
    var minFrameRateValue = 0;
    var maxFrameRateValue = 1;
    this.sliderFrameRate = 
    createSlider(minFrameRateValue, 
                 maxFrameRateValue, 0);
    this.sliderFrameRate.style('width', '50px');
    this.sliderFrameRate.style('height', '20px');
    
    //MIN and MAX Values for Cursors
    var minColorModeValue = 0;
    var maxColorModeValue = 1;
    this.sliderColorMode = 
    createSlider(minColorModeValue, 
                 maxColorModeValue, 0);
    this.sliderColorMode.style('width', '50px');
    this.sliderColorMode.style('height', '20px');
    
    //MIN and MAX Values for Cursors
    var minCursorParticlesValue = 0;
    var maxCursorParticlesValue = 1;
    this.sliderCursorParticles = 
    createSlider(minCursorParticlesValue, 
                 maxCursorParticlesValue, 0);
    this.sliderCursorParticles.style('width', '50px');
    this.sliderCursorParticles.style('height', '20px');
    
    //MIN and MAX Values for Cursors
    var minMusicbarValue = 0;
    var maxMusicbarValue = 1;
    this.slidermusicBar = 
    createSlider(minMusicbarValue, 
                 maxMusicbarValue, 0);
    this.slidermusicBar.style('width', '50px');
    this.slidermusicBar.style('height', '20px');
    
//--------------------------------------------------------------//
    
    // Playback buttons DRAW
	this.draw = function()
    {   
        //Frequency Bins
        this.frequencyBins = ["bass", 
                              "lowMid", 
                              "highMid", 
                              "treble"];
        
        var spectrum = fourier.analyze(); //Spectrum Analysed
        var energyBass = fourier.getEnergy(this.frequencyBins[0]); //ENERGY BASS initialisation
        var energyLow = fourier.getEnergy(this.frequencyBins[1]); //ENERGY Low initialisation
        var energyHigh = fourier.getEnergy(this.frequencyBins[2]); //ENERGY High initialisation
        var energytreb = fourier.getEnergy(this.frequencyBins[3]); //ENERGY Treb initialisation
        
        //Positions
        //ADVANCE BUTTON
        this.advx = width/2 + 55/width * width;
        this.advy = height - 88 * height / height;
        this.advwidth = 15;
        this.advheight = 15;

        //PREVIOUS BUTTON
        this.prevx = width/2 - 45/width * width;
        this.prevy = height - 88 * height / height;
        this.prevwidth = 15;
        this.prevheight = 15;

        //PLAY BUTTON
        this.playx = width/2;
        this.playy = height - 92 * height / height;
        this.playwidth = 25;
        this.playheight = 25;

        //LOOP BUTTON
        this.loopx = width/3;
        this.loopy = height - 92 * height / height;
        this.loopwidth = 25;
        this.loopheight = 25;

        //VOLUME BUTTON
        this.volx = width - 180 / width * width;
        this.voly = height - 92 * height / height;
        this.volwidth = 25;
        this.volheight = 22.5;

        //MIC BUTTON
        this.micx = width/2.5;
        this.micy = height - 92 * height / height;
        this.micwidth = 25;
        this.micheight = 22.5;
        
        //LOCK BUTTON
        this.lockx = width - width/2.5;
        this.locky = height - 92 * height / height;
        this.lockwidth = 25;
        this.lockheight = 20;
        
        //Menu Button
        this.menux = 25;
        this.menuy = 30;
        this.menuwidth = 75;
        this.menuheight = 5;
        
        //SETTINGS BUTTON
        this.settx = width/1.5/width * width;
        this.setty = height - 92 * height / height;
        this.settwidth = 25;
        this.settheight = 25;

        //myMUSIC BUTTON
        this.myMusicx = 0;
        this.myMusicy = 75;
        this.myMusicwidth = 300;
        this.myMusicheight = 70;

        //recent BUTTON
        this.infox = 0;
        this.infoy = 175;
        this.infowidth = 300;
        this.infoheight = 70;

        //legacy BUTTON
        this.legacyx = 0;
        this.legacyy = 275;
        this.legacywidth = 300;
        this.legacyheight = 70;  
        
//----------------Slider Position and Visibility----------------//

        noFill();
        stroke(255);
        this.sliderShape.position(345,150);
        this.sliderShape.hide();
        
        this.sliderShapeSize.position(345,225);
        this.sliderShapeSize.hide();
        
        this.sliderRandomSeed.position(345,300);
        this.sliderRandomSeed.hide();
        
        this.sliderVelocity.position(345,375);
        this.sliderVelocity.hide();
        
        this.sliderColorRed.position(380,460);
        this.sliderColorRed.hide();
        
        this.sliderColorGreen.position(390,490);
        this.sliderColorGreen.hide();
        
        this.sliderColorBlue.position(380,520);
        this.sliderColorBlue.hide();
        
        this.sliderColorAlpha.position(390,550);
        this.sliderColorAlpha.hide();
        
        this.sliderDivision.position(345,625);
        this.sliderDivision.hide();
        
        this.sliderStrokeSize.position(345,700);
        this.sliderStrokeSize.hide();
        
        this.sliderRandomSpaceImage.position(345,775);
        this.sliderRandomSpaceImage.hide();
        
        this.sliderRandomVehicle.position(345,850);
        this.sliderRandomVehicle.hide();
        
        ////
        
        this.sliderVis.position(345,100);
        this.sliderVis.hide();
        
        this.sliderFilter.position(345,150);
        this.sliderFilter.hide();
        
        this.sliderCursor.position(345,250);
        this.sliderCursor.hide();
        
        this.sliderFrameRate.position(345,350);
        this.sliderFrameRate.hide();
    
        this.sliderColorMode.position(345,450);
        this.sliderColorMode.hide();
        
        this.sliderCursorParticles.position(345,550);
        this.sliderCursorParticles.hide();
        
        this.slidermusicBar.position(345,650);
        this.slidermusicBar.hide();
        
//-----------------------------------------------------------------//    
        //THE MENU
        if(menu && !startMenu ||
           menu && !about ||
           menu && !lock ||
           menu && !startMenu && 
           !about && 
           !lock)
        {
            //My Music
            if(this.myMusic)
            { 
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textSize(25);
                text("My Music: ",
                     350,50);
                
                fill(255);
                stroke(0);
                
                fill(0);
                noStroke();
                rect(300,0,
                     width,
                     height);
                
                //Blob Variables
                push();
                noStroke();
                step;
                n = 80; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = width - 300;
                noiseProg = (x) => (x*x);

                step = 0.01;

                var t = frameCount/250;
                kMax = noise(t/2);
                if (!loadingS && 
                    !startMenu)
                {
                    frameCount = 0;
                }

                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, width, height/2, k, t + i * step, noisiness);
                }
                pop();
                
                for (var i = 1; i <= 6;i++)
                {
                    fill(randomR,
                         randomG,
                         randomB);
                    stroke(randomR + 25,
                           randomG + 25,
                           randomB + 25);
                    strokeWeight(2);
                    
                    rect(375,(i * 100 - 100) + 50 * i,100,100,5);
                    fill(randomR - 25,
                         randomG - 25,
                         randomB - 25);
                    ellipse(425,(i * 100 - 50) + 50 * i,90,90);
                    image(MusicIMG,375,(i * 100 - 100) + 50 * i,100,100,5);

                    fill(255);
                    stroke(0);
                    
                    textSize(20);
                    strokeWeight(2);
                    fill(255);
                    textFont("Fugaz One");
                    stroke(0);
                    text(Music[i - 1],490,(i * 100 - 50) + 50 * i,width - 500);
                    textFont("Harlow Solid");
                }
                
                if (sound == MyMusic[0])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         50,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
                
                else if (sound == MyMusic[1])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         200,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
                
                else if (sound == MyMusic[2])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         350,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
                
                else if (sound == MyMusic[3])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         500,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
                
                else if (sound == MyMusic[4])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         650,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
                
                else if (sound == MyMusic[5])
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    noStroke();
                    rect(350,
                         800,
                         15,
                         100,
                         10);
                    strokeWeight(2);
                }
            }
            
            //Tutorial
            if(this.info)
            { 
                fill(0);
                noStroke();
                rect(300,0,width,height);
                
                //Blob Variables
                push();
                noStroke();
                step;
                n = 80; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = width - 300;
                noiseProg = (x) => (x*x);

                step = 0.01;

                var t = frameCount/250;
                kMax = noise(t/2);
                if (!loadingS && 
                    !startMenu)
                {
                    frameCount = 0;
                }

                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, width, height/2, k, t + i * step, noisiness);
                }
                pop();
                
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textSize(25);
                
                textFont("Fugaz One");
                fill(randomR + 25,
                     randomG + 25,
                     randomB + 25);
                text("#How to use the Microphone",350,50,width - 400);
                fill(255);
                text("Step 1: Plug in a Headset or Earphone with a Microphone.",
                     350,80,width - 400);
                text("Step 2: Go to the Sound settings on Windows and enable the microphone device you want to use.",
                     350,140,width - 400);
                text("Step 3: Enable the microphone setting on the music bar.",
                     350,200,width - 400);
                text("Step 4: Allow the app to use the microphone and then press play.",
                     350,260,width - 400);
                text("Step 5: Play any music on windows and watch the visualizations react.",
                     350,320,width - 400);
                
                fill(randomR + 25,
                     randomG + 25,
                     randomB + 25);
                text("#How to change Visualizations",
                     350,430,width - 400);
                fill(255);
                text("Use the Top number keys 1 - 9 for basic visualizations",
                     350,460,width - 400);
                text("Legacy Visualizations are available in the Legacy Tab",
                     350,510,width - 400);
                
                fill(randomR + 25,
                     randomG + 25,
                     randomB + 25);
                text("#How to modify Visualizations",
                     350,630,width - 400);
                fill(255);
                text("Use the Visualizations' Mods Tab to Modify each Visualization",
                     350,660,width - 400);
                text("Each Visualization has attributes that can be modified",
                     350,720,width - 400);
                
                textFont("Harlow Solid");
            }
            
            //legacy
            if(this.legacy)
            {
                fill(0);
                rect(300,0,width - 300, 150);
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textFont("Fugaz One");
                textSize(25);
                
                //Other Visualizations
                text("VisualiZations Mode: ",
                     350,100);
                visType = this.sliderVis.value();
                
                if (visType == 0)
                { 
                    text("Basic - Use the num keys 1 - 9",
                         620,100,width - 400);
                }
                
                else if (visType == 1)
                { 
                    text("Legacy - Quantum Unstable by CHE YU WU",
                         620,100,width - 400);
                }
                
                else if (visType == 2)
                { 
                    text("Legacy - Waves by Wenj",
                         620,100,width - 400);
                }
                
                else if (visType == 3)
                { 
                    text("Legacy - Space Odyssey by Roni Kaufman",
                         620,100,width - 400);
                }
                
                else if (visType == 4)
                { 
                    text("Legacy - A2 Music Visualization by Eddie Chen",
                         620,100,width - 400);
                }
                
                else if (visType == 5)
                { 
                    text("Legacy - Time Arc by Richard Bourne",
                         620,100,width - 400);
                }
                
                else if (visType == 6)
                { 
                    text("Legacy - Matrix Rain by Peter Farrell",
                         620,100,width - 400);
                }
                
                else if (visType == 7)
                { 
                    text("Legacy - 0122 (WEB) by Kusakari",
                         620,100,width - 400);
                }
                
                else if (visType == 8)
                { 
                    text("Legacy - Bursting by Roni Kaufman",
                         620,100,width - 400);
                }
                
                this.sliderVis.show();
                textFont("Harlow Solid");
            }
            
            //Visualization Mods
            if(this.visualiZationMods)
            {
                fill(randomR - 25,
                     randomG - 25,
                     randomB - 25);
                stroke(255);
                rect(300,0,425,height);
                
                                //Blob Variables
                push();
                noStroke();
                step;
                n = 50; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = 1000;
                noiseProg = (x) => (x*x);

                step = 0.01;

                var t = frameCount/250;
                kMax = noise(t/2);
                if (!loadingS && 
                    !startMenu)
                {
                    frameCount = 0;
                }
                
                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, 0, height/2, k, t + i * step, noisiness);
                }
                pop();
                
                fill(randomR,randomG,randomB);
                rect(325,125,370,50);
                rect(325,200,370,50);
                rect(325,275,370,50);
                rect(325,350,370,50);
                rect(325,425,370,150);
                rect(325,600,370,50);
                rect(325,675,370,50);
                rect(325,750,370,50);
                rect(325,825,370,50);
                
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textSize(25);
                
                //Shape
                if (vis.selectedVisual.name != "Music Clock" &&             
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "Pure Energy")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,125,370,50);
                    fill(255);
                    textFont("Fugaz One");
                    text("Shape Mode: ",350,150);
                    Deform = this.sliderShape.value();

                    if(Deform == 0)
                    {
                       shapeType = "Line"
                    }
                    else if(Deform == 1)
                    {
                        shapeType = "Square"
                    }
                    else if(Deform == 2)
                    {
                        shapeType = "Circle";
                    }
                    text(shapeType,520,150);

                    if(startMenu)
                    {
                        this.sliderShape.hide();
                    }
                    else
                    {
                        this.sliderShape.show();
                    }
                }
                
                //Shape Size
                if (vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,200,370,50);
                    fill(255);
                    text("Shape Size Mode: ",350,225);
                    ShapeSize = this.sliderShapeSize.value();

                    if (ShapeSize == 50)
                    {
                        text(ShapeSize + " (max)",
                             570,225);
                    }

                    else if (ShapeSize == 0)
                    {
                        text(ShapeSize + " (min)",
                             570,225);
                    }

                    else
                    {
                        text(ShapeSize,
                             570,225);
                    }

                    if(startMenu)
                    {
                        this.sliderShapeSize.hide();
                    }
                    else
                    {
                        this.sliderShapeSize.show();
                    }
                }

                //Random
                if (vis.selectedVisual.name != "Beat" &&
                    vis.selectedVisual.name != "Vertex Particles" &&
                    vis.selectedVisual.name != "Sound Waves" &&
                    vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Waves" &&
                    vis.selectedVisual.name != "A2" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "www.Web")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,275,370,50);
                    fill(255);
                    text("Random Mode: ",350,300);
                    Seed = this.sliderRandomSeed.value();

                    if (Seed == 50)
                    {
                        text(Seed + " (max)",540,300);
                    }

                    else if (Seed == 0)
                    {
                        text(Seed + " (min)",540,300);
                    }

                    else
                    {
                        text(Seed,540,300);
                    }
                    this.sliderRandomSeed.show();
                }
                
                if (vis.selectedVisual.name != "Beat" &&
                    vis.selectedVisual.name != "Sound Waves" &&
                    vis.selectedVisual.name != "Vertex Chord" &&
                    vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Holo Mesh" &&
                    vis.selectedVisual.name != "Waves" &&
                    vis.selectedVisual.name != "A2" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "www.Web" &&
                    vis.selectedVisual.name != "Pure Energy")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,350,370,50);
                    fill(255);
                    //Velocity
                    text("Velocity Mode: ",
                         350,375);
                    Velocity = this.sliderVelocity.value();

                    if (Velocity == 10)
                    {
                        text(Velocity + " (max)",
                             535,375);
                    }

                    else if (Velocity == 0)
                    {
                        text(Velocity + " (min)",
                             535,375);
                    }

                    else
                    {
                        text(Velocity,
                             535,375);
                    }
                    this.sliderVelocity.show();
                }
                //Color
                fill(randomR + 25,
                     randomG + 25,
                     randomB + 25);
                rect(325,425,370,150);
                fill(255);
                text("Color Settings: ",
                     350,450);
                
                Red_Colour = this.sliderColorRed.value();
                Green_Colour = this.sliderColorGreen.value();
                Blue_Colour = this.sliderColorBlue.value();
                Alpha_Fill = this.sliderColorAlpha.value();
                
                var Red = round(Red_Colour/255 * 100);
                var Green = round(Green_Colour/255 * 100);
                var Blue = round(Blue_Colour/255 * 100);
                var Alpha = round(Alpha_Fill/255 * 100);
                
                textSize(15);
                text("Red               " + Red + "%",
                     350,470);
                text("Green               " + Green + "%",
                     350,500);
                text("Blue               " + Blue + "%",
                     350,530);
                text("Alpha               " + Alpha + "%",
                     350,560);
                
                fill(Red_Colour,
                     Green_Colour,
                     Blue_Colour);
                ellipse(600,500,100);
                fill(Alpha_Fill,255 - Alpha_Fill);
                ellipse(640,500,100);
                
                fill(Red_Colour,0,0);
                ellipse(490,465,20);
                fill(0,Green_Colour,0);
                ellipse(495,495,20);
                fill(0,0,Blue_Colour);
                ellipse(490,525,20);
                fill(0,0,0,255 - Alpha_Fill);
                ellipse(495,555,20);
                
                this.sliderColorRed.show();
                this.sliderColorGreen.show();
                this.sliderColorBlue.show();
                this.sliderColorAlpha.show();
                
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textSize(25);
                
                //Division
                if (vis.selectedVisual.name != "Beat" &&
                    vis.selectedVisual.name != "Vertex Particles" &&
                    vis.selectedVisual.name != "Vertex Chord" &&
                    vis.selectedVisual.name != "Sound Waves" &&
                    vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Holo Mesh" &&
                    vis.selectedVisual.name != "Spectro" &&
                    vis.selectedVisual.name != "Rain Particles" &&
                    vis.selectedVisual.name != "Quantum Unstable" && 
                    vis.selectedVisual.name != "Waves" &&
                    vis.selectedVisual.name != "Space Odyssey" &&
                    vis.selectedVisual.name != "A2" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "www.Web" &&
                    vis.selectedVisual.name != "Pure Energy")
                {
                    fill(randomR + 25,randomG + 25,randomB + 25);
                    rect(325,600,370,50);
                    fill(255);
                    text("Division Mode: ",350,625);
                    Divisions = this.sliderDivision.value();

                    if (Divisions == 10)
                    {
                        text(Divisions + " (max)",
                             535,625);
                    }

                    else if (Divisions == 0)
                    {
                        text(Divisions + " (min)",
                             535,625);
                    }

                    else
                    {
                        text(Divisions,
                             535,625);
                    }
                    this.sliderDivision.show();
                }
                
                //Stroke Size
                if (vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,675,370,50);
                    fill(255);
                    text("Stroke Size Mode: ",
                         350,700);
                    StrokeSize = this.sliderStrokeSize.value();

                    if (StrokeSize == 20)
                    {
                        text(StrokeSize + " (max)",
                             580,700);
                    }

                    else if (StrokeSize == 0)
                    {
                        text(StrokeSize + " (min)",
                             580,700);
                    }

                    else
                    {
                        text(StrokeSize,
                             580,700);
                    }
                    this.sliderStrokeSize.show();
                }
                
                //Space Image
                if (vis.selectedVisual.name != "Beat" &&
                    vis.selectedVisual.name != "Vertex Particles" &&
                    vis.selectedVisual.name != "Vertex Chord" &&
                    vis.selectedVisual.name != "Sound Waves" &&
                    vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Holo Mesh" &&
                    vis.selectedVisual.name != "Spectro" &&
                    vis.selectedVisual.name != "Rain Particles" &&
                    vis.selectedVisual.name != "Mount Aves" &&
                    vis.selectedVisual.name != "Quantum Unstable" && 
                    vis.selectedVisual.name != "Waves" &&
                    vis.selectedVisual.name != "A2" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "www.Web" &&
                    vis.selectedVisual.name != "Pure Energy")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,750,370,50);
                    fill(255);
                    text("Space: ",350,775);
                    RandomSpaceImage = this.sliderRandomSpaceImage.value();

                    text("Area 0" + RandomSpaceImage ,440,775);
                    
                    this.sliderRandomSpaceImage.show();
                }
                
                //Space Vehicle
                if (vis.selectedVisual.name != "Beat" &&
                    vis.selectedVisual.name != "Vertex Particles" &&
                    vis.selectedVisual.name != "Vertex Chord" &&
                    vis.selectedVisual.name != "Sound Waves" &&
                    vis.selectedVisual.name != "Needles" &&
                    vis.selectedVisual.name != "Holo Mesh" &&
                    vis.selectedVisual.name != "Spectro" &&
                    vis.selectedVisual.name != "Rain Particles" &&
                    vis.selectedVisual.name != "Mount Aves" &&
                    vis.selectedVisual.name != "Quantum Unstable" && 
                    vis.selectedVisual.name != "Waves" &&
                    vis.selectedVisual.name != "A2" &&
                    vis.selectedVisual.name != "Music Clock" &&
                    vis.selectedVisual.name != "The Matrix" &&
                    vis.selectedVisual.name != "www.Web" &&
                    vis.selectedVisual.name != "Pure Energy")
                {
                    fill(randomR + 25,
                         randomG + 25,
                         randomB + 25);
                    rect(325,825,370,50);
                    fill(255);
                    text("Vehicle: ",
                         350,850);
                    RandomVehicle = this.sliderRandomVehicle.value();

                    text("Type 0" + RandomVehicle ,
                         455,850);
                    
                    this.sliderRandomVehicle.show();
                }
            }
            
            //Settings
            if(this.settings)
            {
                fill(randomR - 25,
                     randomG - 25,
                     randomB - 25);
                stroke(255);
                rect(300,0,420,height);
                fill(0,50);
                rect(720,0,width - 720,height);
                
                //Blob Variables
                push();
                noStroke();
                step;
                n = 50; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = 1000;
                noiseProg = (x) => (x*x);

                step = 0.01;

                var t = frameCount/250;
                kMax = noise(t/2);
                if (!loadingS && 
                    !startMenu)
                {
                    frameCount = 0;
                }

                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, 0, height/2, k, t + i * step, noisiness);
                }
                
                //Blob Variables
                push();
                noStroke();
                step;
                n = 50; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = width - 720;
                noiseProg = (x) => (x*x);

                step = 0.01;

                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, width, height/2, k, t + i * step, noisiness);
                }
                pop();
                //////////////////
                
                fill(randomR + 25,
                     randomG + 25,
                     randomB + 25);
                stroke(255);
                rect(325,125,380,50);
                rect(325,225,380,50);
                rect(325,325,380,50);
                rect(325,425,380,50);
                rect(325,525,380,50);
                rect(325,625,380,50);
                
                var FilterValue = this.sliderFilter.value();
                textFont("Fugaz One");
                if(FilterValue == 1)
                {
                   Filter = "Standard"
                }
                else if(FilterValue == 2)
                {
                    Filter = "Warm"
                }
                else if(FilterValue == 3)
                {
                    Filter = "Cold";
                }
                        
                fill(255);
                stroke(0);
                strokeWeight(2.5);
                textSize(25);
                
                text("Filter Mode: ",
                     350,150);
                
                text(Filter,510,150);
                this.sliderFilter.show();
                
                
                CursorValue = this.sliderCursor.value();
                
                if(CursorValue == 1)
                {
                    cursorType = "Circle";
                }
                
                if(CursorValue == 2)
                {
                    cursorType = "Square";
                }
                
                if(CursorValue == 3)
                {
                    cursorType = "Grid";
                }
                
                if(CursorValue == 4)
                {
                    cursorType = "Dot";
                }
                
                text("Cursor Type: ",
                     350,250);
                text(cursorType,
                     520,250);
                this.sliderCursor.show();
                
                FrameRateValue = this.sliderFrameRate.value();
                
                if(FrameRateValue == 0)
                {
                    FrameRateType = "Off";
                    showFrames = false;
                }
                
                if(FrameRateValue == 1)
                {
                    FrameRateType = "On";
                    showFrames = true;
                }
                
                text("Display Frame Rate: ",
                     350,350);
                text(FrameRateType,
                     610,350);
                this.sliderFrameRate.show();
                
                ColorModeValue = this.sliderColorMode.value();
                
                if(ColorModeValue == 0)
                {
                    ColorModeType = "RGB (Default)";
                    ModeColor = RGB;
                }
                
                if(ColorModeValue == 1)
                {
                    ColorModeType = "HSB (Alternate)";
                    ModeColor = HSB;
                }
                
                text("Color Mode: ",
                     350,450);
                text(ColorModeType,
                     505,450, windowWidth - 800);
                this.sliderColorMode.show();
                
                CParticleValue = this.sliderCursorParticles.value();
                
                if(CParticleValue == 0)
                {
                    CParticleType = "Off";
                    CParticles = false;
                }
                
                if(CParticleValue == 1)
                {
                    CParticleType = "On";
                    CParticles = true;
                }
                
                text("Cursor Particles: ",
                     350,550);
                text(CParticleType,
                     575,550, windowWidth - 900);
                this.sliderCursorParticles.show();
                
                musicBarValue = this.slidermusicBar.value();
                
                if(musicBarValue == 0)
                {
                    musicBarType = "Square";
                }
                
                if(musicBarValue == 1)
                {
                    musicBarType = "Circle";

                }
                
                text("Music Bar Type: ",
                     350,650);
                text(musicBarType,
                     555,650, windowWidth - 900);
                this.slidermusicBar.show();
            }
            else
            {
                this.sliderCursor.hide();
                this.sliderFilter.hide();
                this.sliderFrameRate.hide();
                this.sliderColorMode.hide();
                this.sliderCursorParticles.hide();
                this.slidermusicBar.hide();
            }
            
            //Side menu
            if (this.visualiZationMods || 
                this.settings)
            {
                fill(randomR,
                     randomG,
                     randomB);
            }
            else
            {
                fill(randomR,
                     randomG,
                     randomB,
                     mouseX/300 * 255);
            }
            stroke(255);
            rect(0,0,300/width * width,height);
            
            fill(50,0);
            rect(300,0,width - 300,height);
            fill(25,50);
            
            
            noStroke();
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > 75 &&
                mouseY < 75 + 70 || 
                this.myMusic)
            {
                fill(25,50);
                rect(0,75,300,70); 
            }
            if (this.myMusic)
            {
                fill(randomR + 50,
                     randomG + 50,
                     randomB + 50);
                rect(10,85,10,50); 
            }
            
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > 175 &&
                mouseY < 175 + 70 || 
                this.info)
            {
                fill(25,50);
                rect(0,175,300,70); 
            }
            if (this.info)
            {
                fill(randomR + 50,
                     randomG + 50,
                     randomB + 50);
                rect(10,185,10,50); 
            }
            
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > 275 &&
                mouseY < 275 + 70 || 
                this.legacy)
            {
                fill(25,50);
                rect(0,275,300,70);
            }
            if (this.legacy)
            {
                fill(randomR + 50,
                     randomG + 50,
                     randomB + 50);
                rect(10,285,10,50); 
            }
            
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > 375 &&
                mouseY < 375 + 70 || 
                this.visualiZationMods)
            {
                fill(25,50);
                rect(0,375,300,70);
            }
            if (this.visualiZationMods)
            {
                fill(randomR + 50,
                     randomG + 50,
                     randomB + 50);
                rect(10,385,10,50); 
            }
            
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > 475 &&
                mouseY < 475 + 70)
            {
                fill(25,50);
                rect(0,475,300,70);
            }
            
            if (mouseX > 0 &&
                mouseX < 0 + 300 &&
                mouseY > height - 140 &&
                mouseY < height - 140 + 70 || 
                this.settings)
            {
                fill(25,50);
                rect(0,height - 140,300,70);
            }
            if (this.settings)
            {
                fill(randomR + 50,
                     randomG + 50,
                     randomB + 50);
                rect(10,height - 130,10,50); 
            }
            
            fill(255);
            stroke(0);
            strokeWeight(2.5);
            textFont("Harlow Solid");
            textSize(25);
            text("My Music", 50,120);
            text("Tutorial", 50,220);
            text("Legacy Visualizations", 50,320);
            text("VisualiZation Mods", 50,420);
            text("Quick Menu", 50,520);
            text("Settings", 50,height - 95);
            
            //menu
            fill(255,255 - mouseX/width * 255);
            stroke(255,255 - mouseX/width * 255);
            rect(this.menux,
                 this.menuy - 10,
                 this.menuwidth,
                 this.menuheight);
            
            rect(this.menux,
                 this.menuy,
                 this.menuwidth,
                 this.menuheight);
            
            rect(this.menux,
                 this.menuy + 10,
                 this.menuwidth,
                 this.menuheight);
        }
        else if(dist(mouseX,
                     mouseX, 
                     width,
                     width) > 0 &&
                dist(mouseY,
                     mouseY, 
                     height/1.01,
                     height/1.01) > 200 && 
                menu == false &&
                !lock) 
        {	
            fill(255,255 - mouseX/width * 255);
            strokeWeight(0.5);
            stroke(127.5,255 - mouseX/width * 255);
            rect(this.menux,
                 this.menuy - 15,
                 this.menuwidth,
                 this.menuheight);
            
            rect(this.menux,
                 this.menuy,
                 this.menuwidth,
                 this.menuheight);
            
            rect(this.menux,
                 this.menuy + 15,
                 this.menuwidth,
                 this.menuheight);
        } 
        
        fill(50);
        translate(0,200);
        if (dist(mouseX,
                 mouseX, 
                 width,
                 width) > 0 &&
            dist(mouseY,
                 mouseY, 
                 height/1.01,
                 height/1.01) < 200 &&
            menu != true ||
            lock)
        {  
            translate(0,-200);
        }
        
        //The Music Box
        fill(mouseX/width * Red_Colour/2, 
             mouseX/width * Green_Colour/2, 
             mouseX/width * Blue_Colour/2,
             mouseX/width * 100);
        
        
        rect(75 / width * width,
             height - 150 * height/height,
             width - 75,
             160,10);
        
    
        noStroke();
        fill(0,mouseX/width * 100);
        rect(75 / width * width,
             height - 150 * height/height,
             width - 75,
             40,10);     
        
        stroke(255);
        fill(randomR - 15,
             randomG - 15,
             randomB - 15);
        
        if(musicBarValue == 0)
        {
            rect(0,height - 150 * height/height,
                 150 / width * width,
                 150/ height * height);
        }
        
        if (musicBarValue == 1)
        {
            ellipse(75,
                    height - 75 * height/height,
                    150 / width * width,
                    150/ height * height);
        }
        
        //Music Blob Square
        //Blob Variables
        push();
        noStroke();
        step;
        n = 30; // number of blobs
        radius = 2; // diameter of the circle
        inter = 1; // difference between the sizes of two blobs
        maxNoise = energytreb/102.4 * 60;
        noiseProg = (x) => (x*x);

        step = 0.01;
        
        var t = frameCount/250;
        kMax = noise(t/2);
        if (!loadingS && 
            !startMenu)
        {
            frameCount = 0;
        }
        
        for (var i = n; i >= 0; i--) 
        {
            var alpha = 1 - noiseProg(i / n);
            fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
            var size = radius + i * inter;
            var k = kMax * sqrt(i/n);
            var noisiness = maxNoise * noiseProg(i / n);
            blob(size, 75, height - 75, k, t + i * step, noisiness);
        }
        pop();
        //////////////////
        
        //Song Image
        image(MusicIMG,0,height - 150 * height/height,
             150 / width * width,
             150/ height * height);
        
        //Indicators
        fill(255);
        if (dist(mouseX,
                 mouseX,
                 width,
                 width) > 0 &&
            dist(mouseY,
                 mouseY, 
                 height/1.01,
                 height/1.01) < 200 &&
            menu != true ||
            lock)
        {
            stroke(0);
            strokeWeight(2);
            textSize(20);
            textFont("Harlow Solid");
            
            if(this.sliderSound.value() == 0 && 
               !this.volume)
            {
                text("Volume: 0%", 10,75);
            }
            else if(this.sliderSound.value() == 0 && 
                    this.volume)
            {
                text("Volume: Muted", 10,75);
            }
            else if(this.sliderSound.value() == 100)
            {
                text("Volume: 100% (Max)", 10,75);
            }
            else
            {
                text("Volume: " + this.sliderSound.value() + "%", 10,75);   
            }
            
            text("Visualistaion: " + vis.selectedVisual.name, 10,25);
            noStroke();
        }
        
        //ADVANCE BUTTON DRAW
        noFill();
        stroke(255);
        if(this.advance)
        {
            triangle(this.advx,
                     this.advy,
                     this.advx + this.advwidth, 
                     this.advy + this.advheight/2,
                     this.advx, this.advy + this.advheight);
            
            triangle(this.advx + 10, 
                     this.advy, this.advx + 10 + this.advwidth, 
                     this.advy + this.advheight/2, 
                     this.advx + 10, this.advy + this.advheight);
		}
		else
        {	
			triangle(this.advx, 
                     this.advy, 
                     this.advx + this.advwidth, 
                     this.advy + this.advheight/2, 
                     this.advx, 
                     this.advy + this.advheight);
		}
        
        //PREVIOUS BUTTON DRAW
        if(this.previous)
        {
            triangle(this.prevx + 10, 
                     this.prevy, 
                     this.prevx - 20 + this.prevwidth, 
                     this.prevy + this.prevheight/2, 
                     this.prevx + 10, 
                     this.prevy + this.prevheight);
            
            triangle(this.prevx , 
                     this.prevy, 
                     this.prevx - 30 + this.prevwidth,
                     this.prevy + this.prevheight/2, 
                     this.prevx, 
                     this.prevy + this.prevheight);
		}
		else
        {	
            triangle(this.prevx + 10, 
                     this.prevy, 
                     this.prevx - 20 + this.prevwidth, 
                     this.prevy + this.prevheight/2, 
                     this.prevx + 10, 
                     this.prevy + this.prevheight);
		}
        
        ellipse(this.playx + 12,
             this.playy + 12,50,50);
        
        //PLAY BUTTON DRAW
		if(sound.isPlaying())
        {
                rect(this.playx - 2, 
                     this.playy, 
                     this.playwidth/2 - 2, 
                     this.playheight);

                rect(this.playx + (this.playwidth/2 + 2), 
                     this.playy, 
                     this.playwidth/2 - 2, 
                     this.playheight);
		}
        
        else if (sound.isPaused())
        {	
			triangle(this.playx, 
                     this.playy, 
                     this.playx + this.playwidth, 
                     this.playy + this.playheight/2, 
                     this.playx, 
                     this.playy + this.playheight);
		}
        else
        {
            triangle(this.playx, 
                     this.playy, 
                     this.playx + this.playwidth, 
                     this.playy + this.playheight/2, 
                     this.playx, 
                     this.playy + this.playheight);
        }
        
        //LOOP BUTTON DRAW
		if(this.looping)
        {
            strokeWeight(1);
			rect(this.loopx -2, 
                 this.loopy -2, 
                 this.loopwidth + 4, 
                 this.loopheight + 4,5);
            
			image(LoopIMG,this.loopx, 
                 this.loopy, 
                 this.loopwidth, 
                 this.loopheight);
		}
		else
        {	
			image(LoopIMG,this.loopx, 
                 this.loopy, 
                 this.loopwidth, 
                 this.loopheight);
		}
        
//------------------------------------------------------------------//
        
        //SPEED SLIDER POSTION
        this.sliderSpeed.position(width - 150 / width * width, 
                 height - 58/ height * height);
        
        var playbackRate =  this.sliderSpeed.value();
        
        sound.rate(playbackRate);
        
        textSize(20);
        strokeWeight(1);
        
        if (dist(mouseX,
                 mouseX, 
                 width,
                 width) > 0 &&
            dist(mouseY,
                 mouseY, 
                 height/1.01,
                 height/1.01) < 200 &&
            menu != true ||
            lock)
        {
            fill(255);
            if (playbackRate >= 0)
            {
                noStroke();
                text("x " + playbackRate,width - 180 / width * width,
                     height - 47/ height * height);
                
                stroke(0);
                strokeWeight(2);
                textSize(20);
                text("Speed: " + playbackRate + "  >>",10,50);
            }
            else
            {
                noStroke();
                text("/ " + playbackRate,width - 180 / width * width,
                     height - 45/ height * height);
                
                stroke(0);
                strokeWeight(2);
                textSize(20);
                text("Speed: <<  " + playbackRate,10,50);
            }
            noStroke();
            noFill();
        }
        
        //VOLUME SLIDER POSITION
        this.sliderSound.position(width - 150 / width * width, 
                 height - 90/ height * height);
        
        var volumeVal = this.sliderSound.value();

        sound.setVolume(volumeVal/100 * 1);
        
        if (dist(mouseX,
                 mouseX, 
                 width,
                 width) > 0 &&
            dist(mouseY,
                 mouseY, 
                 height/1.01,
                 height/1.01) < 200 &&
            menu != true && 
            !startMenu && 
            !loadingS && 
            !about ||
            lock)
        {
            this.sliderSound.show();
            this.sliderSpeed.show();
        }
        else
        {
            this.sliderSound.hide();
            this.sliderSpeed.hide();
        }
        
        if(startMenu)
        {
            this.sliderSound.hide();
            this.sliderSpeed.hide();
        }
         
//-----------------------------------------------------------------//
        
        //VOLUME/MUTE BUTTON DRAW
		if(this.volume)
        { 
			image(MuteIMG,
                  this.volx, 
                  this.voly - 3, 
                  this.volwidth, 
                  this.volheight);
            
            if (!gotSound)
            {
                previousVolume =  this.sliderSound.value();
                this.sliderSound.value(0);
                gotSound = true;
            }
            
            if (this.sliderSound.value() > 0 && 
               this.volume)
            {
                this.volume = !this.volume;
            }
		}
		else
        {	
			image(VolumeIMG,
                  this.volx, 
                  this.voly -3, 
                  this.volwidth - 2.5, 
                  this.volheight);
            
            if (gotSound)
            {
                this.sliderSound.value(previousVolume);
                gotSound = false;
            }
		}
        
        //MIC BUTTON DRAW
		if(mic)
        {
            image(NoMicIMG,
                  this.micx, 
                  this.micy, 
                  this.micwidth, 
                  this.micheight );
            
            microphone.stop();
            fourier.setInput(sound);
		}
		else
        {   
			image(MicIMG,
                  this.micx + 4, 
                  this.micy + 1, 
                  this.micwidth - 8, 
                  this.micheight - 2);   
            
            this.playing = false;
            
            sound.stop();
            microphone.start();
            fourier.setInput(microphone);
        }
        
        //LOCK BUTTON DRAW
		if(lock)
        {
            image(LockIMG,
                  this.lockx + 9, 
                  this.locky, 
                  this.lockwidth - 9, 
                  this.lockheight);
		}
		else
        {   
			image(UnLockIMG,
                  this.lockx, 
                  this.locky, 
                  this.lockwidth, 
                  this.lockheight);   
        }
	};
    
//-----------------------------------------------------------------//
    
    //HIT CHECKS
	//checks for clicks on the button, starts or pauses playabck.
	//@returns true if clicked false otherwise.
	this.hitCheck = function()
    {
        if (!startMenu && !about)
        {
            //ADV HC
            if(mouseX > this.advx && 
               mouseX < this.advx + this.advwidth && 
               mouseY > this.advy && 
               mouseY < this.advy + this.advheight)
            {
                if (this.sliderSpeed.value() == 1)  
                {
                   this.sliderSpeed.value(2);
                } 

                else
                {
                   this.sliderSpeed.value(1);
                }
                
                if (this.previous)
                {
                    this.sliderSpeed.value(2);
                    this.previous = false;
                }

                this.advance = !this.advance;
                return true;
            }

            //PREV HC
            if(mouseX > this.prevx && 
               mouseX < this.prevx + this.prevwidth && 
               mouseY > this.prevy && 
               mouseY < this.prevy + this.prevheight)
            {
                if (this.sliderSpeed.value() == 1) 
                {
                    this.sliderSpeed.value(-2);
                } 

                else
                {
                    this.sliderSpeed.value(1);
                }
                
                if (this.advance)
                {
                    this.sliderSpeed.value(-2);
                    this.advance = false;
                }

                this.previous = !this.previous;
                return true;
            }

            //PLAY HC
            if(dist(this.playx + 12,
                    this.playy + 12,
                    mouseX,
                    mouseY)< 25)
            {
                if (sound.isPlaying()) 
                {
                    sound.pause();

                    this.sliderSpeed.value(1);
                } 
                else 
                {   
                    sound.play();
                }
                
                if(this.advance && this.previous ||
                  this.advance || this.previous)
                {
                    this.previous = false;
                    this.advance = false;
                    this.sliderSpeed.value(1);
                    sound.pause();
                }
                
                this.playing = !this.playing;
                return true;
            }

            //LOOP HC
            if(mouseX > this.loopx && 
               mouseX < this.loopx + this.loopwidth && 
               mouseY > this.loopy && 
               mouseY < this.loopy + this.loopheight)
            {
                if (sound.isLooping()) 
                {
                    sound.stop();
                    sound.play();
                } 

                else 
                {   
                    sound.stop();
                    sound.loop();
                    this.playing = true;
                }
                this.looping = !this.looping;
                return true;
            }

            //VOL HC
            if(mouseX > this.volx && 
               mouseX < this.volx + this.volwidth && 
               mouseY > this.voly - 6 && 
               mouseY < this.voly + this.volheight)
            {
                this.volume = !this.volume;
                return true;
            }

            //MIC HC
            if(mouseX > this.micx && 
               mouseX < this.micx + this.micwidth && 
               mouseY > this.micy && 
               mouseY < this.micy + this.micheight)
            {
                mic = !mic;
                return true;
            }
            
            //LOCK HC
            if(mouseX > this.lockx && 
               mouseX < this.lockx + this.lockwidth && 
               mouseY > this.locky && 
               mouseY < this.locky + this.lockheight)
            {
                lock = !lock;
                return true;
            }

            //MENU HC
            if(mouseX > this.menux && 
               mouseX < this.menux + this.menuwidth + 5 && 
               mouseY > this.menuy - 15 && 
               mouseY < this.menuy + this.menuheight + 15 &&
              !startMenu && !about && !lock)
            {
                menu = !menu;
                return true;
            }

            if (menu)
            {
                ///MY Music Interaction
                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > 75 && 
                   mouseY < 75 + 70)
                {
                    this.myMusic = !this.myMusic;
                    this.info = false;
                    this.legacy = false;
                    this.settings = false;
                    this.visualiZationMods = false;
                    return true;
                }
                
                if (dist(mouseX,
                         mouseY,
                         425,
                         100) < 50 && 
                    this.myMusic)
                {
                    sound.pause();
                    sound.stop();
                    sound = MyMusic[0];
                    songName = Music[0];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                else if (dist(mouseX,
                              mouseY,
                              425,
                              250) < 50 && 
                         this.myMusic)
                {
                    sound.stop();
                    sound = MyMusic[1];
                    songName = Music[1];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                else if (dist(mouseX,
                              mouseY,
                              425,
                              400) < 50 && 
                         this.myMusic)
                {
                    sound.pause();
                    sound.stop();
                    sound = MyMusic[2];
                    songName = Music[2];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                else if (dist(mouseX,
                              mouseY,
                              425,
                              550) < 50 && 
                         this.myMusic)
                {
                    sound.pause();
                    sound.stop();
                    sound = MyMusic[3];
                    songName = Music[3];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                else if (dist(mouseX,
                              mouseY,
                              425,
                              700) < 50 && 
                         this.myMusic)
                {
                    sound.pause();
                    sound.stop();
                    sound = MyMusic[4];
                    songName = Music[4];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                else if (dist(mouseX,
                              mouseY,
                              425,
                              850) < 50 && 
                         this.myMusic)
                {
                    sound.pause();
                    sound.stop();
                    sound = MyMusic[5];
                    songName = Music[5];
                    songCurrentTime = 0;
                    songCurrentTimetemp = 0;
                    songBar();
                }
                
                ///info
                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > 175 && 
                   mouseY < 175 + 70)
                {
                    this.info = !this.info;
                    this.myMusic = false;
                    this.legacy = false;
                    this.settings = false;
                    this.visualiZationMods = false;
                    return true;
                }

                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > 275 && 
                   mouseY < 275 + 70)
                {
                    this.legacy = !this.legacy;
                    this.myMusic = false;
                    this.info = false;
                    this.settings = false;
                    this.visualiZationMods = false;
                    return true;
                }

                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > 375 && 
                   mouseY < 375 + 70)
                {
                    this.visualiZationMods = !this.visualiZationMods;
                    this.legacy = false;
                    this.myMusic = false;
                    this.info = false;
                    this.settings = false;
                    return true;
                }
                
                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > 475 && 
                   mouseY < 475 + 70)
                {
                    this.quickMenu = !this.quickMenu;
                    this.visualiZationMods = false;
                    this.legacy = false;
                    this.myMusic = false;
                    this.info = false;
                    this.settings = false;
                    startMenu = true;
                    menu = false;
                    return true;
                }

                if(mouseX > 0 && 
                   mouseX < 0 + 300 && 
                   mouseY > height - 140 && 
                   mouseY < height - 140 + 70)
                {
                    this.settings = !this.settings;
                    this.myMusic = false;
                    this.info = false;
                    this.legacy = false;
                    this.visualiZationMods = false;
                    return true;
                }
            }

            //MUSIC BOX HC
            if (dist(mouseX,
                     mouseX, 
                     width,
                     width) > 0 &&
                dist(mouseY,
                     mouseY,
                     height/1.01,
                     height/1.01) < 200 &&
                menu != true ||
                lock)
            {
                return true;
            }

            //MENU BOX HC
            if (mouseX > 0 && 
                mouseX < 0 + 300 && 
                mouseY > 0 && 
                mouseY < 0 + height &&
                menu == true)
            {
                return true;
            }
        }
        
        //Start
        if (mouseX > width/2 - 305 &&
            mouseX < width/2 - 5 &&
            mouseY > height/2 - 305 &&
            mouseY < height/2 - 5 &&
            startMenu)
        {
            startMenu = false;
            return true;
        }
        
        //Music
        if (mouseX > width/2 + 5 &&
            mouseX < width/2 + 305 &&
            mouseY > height/2 - 305 &&
            mouseY < height/2 - 5 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            this.myMusic = true;
            return true;
        }
        
        //Menu
        if (mouseX > width/2 - 305 &&
            mouseX < width/2 - 5 &&
            mouseY > height/2 + 5 &&
            mouseY < height/2 + 305 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            return true;
        }
        
        //About
        if (mouseX > width/2 + 5 &&
            mouseX < width/2 + 305 &&
            mouseY > height/2 + 5 &&
            mouseY < height/2 + 305 &&
            startMenu)
        {
            startMenu = false;
            about = true;
            return true;
        }
        
        if (dist(width - 100,
                 height - 100,
                 mouseX,mouseY) < 50 &&
            about)
        {
            about = false;
            startMenu = true;
            return true;
        }
        
        //VisualizationMods quick button
        if (mouseX > width/2 + 320 + mouseX/width * 10 &&
            mouseX < width - 50 + mouseX/width * 10 &&
            mouseY > height/2 - 300 + mouseY/height * 10 &&
            mouseY < height/2 - 300 + 610 + mouseY/height * 10 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            this.visualiZationMods = true;
            return true;
        }
        
        //Recents quick button
        if (mouseX > width/2 - 300 + mouseX/width * 10 &&
            mouseX < width - 50 + mouseX/width * 10 &&
            mouseY > 25 + mouseY/height * 10 &&
            mouseY < height/2 - 320 + mouseY/height * 10 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            this.info = true;
            return true;
        }
        
        //Settings quick button
        if (mouseX > width/2 - 300 + mouseX/width * 10 &&
            mouseX < width/2 - 300 + 610 + mouseX/width * 10 &&
            mouseY > height/2 + 320 + mouseY/height * 10 &&
            mouseY < height - 50 + mouseY/height * 10 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            this.settings = true;
            return true;
        }
        
        //legacy quick button
        if (mouseX > width/2 + 320 + mouseX/width * 10 &&
            mouseX < width - 50 + mouseX/width * 10 &&
            mouseY > height/2 + 320 + mouseY/height * 10 &&
            mouseY < height - 50 + mouseY/height * 10 &&
            startMenu)
        {
            startMenu = false;
            menu = true;
            this.legacy = true;
            return true;
        }
        
        //PLAY start menu HC
        if(startMenu && 
           sound.isPlaying() &&
           dist(195,80,
                mouseX,
                mouseY) < 35 ||
          startMenu && 
           sound.isPaused() &&
           dist(195,80,
                mouseX,
                mouseY) < 35)
        {
            if (sound.isPlaying()) 
            {
                sound.pause();

                this.sliderSpeed.value(1);
            } 
            else 
            {   
                sound.play();
            }

            if(this.advance && this.previous ||
              this.advance || 
               this.previous)
            {
                this.previous = false;
                this.advance = false;
                this.sliderSpeed.value(1);
                sound.pause();
            }

            this.playing = !this.playing;
            return true;
        }
        
        if(dist(width/2,
                height/2,
                mouseX,
                mouseY) < 100 && 
           visType == 7)
        {
            return true;
        }
        
        return false;
	};
}