//Constructor function to handle the onscreen menu, keyboard and mouse
//controls
function ControlsAndInput(){
	
	this.menuDisplayed = false;
	
	//playback button displayed in the top left of the screen
	this.playbackButton = new PlaybackButton();
    
//---------------------------------------------------------------------------//

	//make the window fullscreen or revert to windowed
	this.mousePressed = function()
    {
        fs = fullscreen();
        
        if(!this.playbackButton.hitCheck() && !menu)
        {
			fullscreen(!fs);
		}
	};
    
//---------------------------------------------------------------------------//
    
	//responds to keyboard presses
	//@param keycode the ascii code of the keypressed
	this.keyPressed = function(keycode)
    {
        push();
		console.log(keycode);
		if(keycode == 32 && !menu)
        {
			this.menuDisplayed = !this.menuDisplayed;
		}
        
		if(keycode > 48 && keycode < 58)
        {
			var VisualisationNum = keycode - 49;
            Visualisation = VisualisationNum;
			vis.selectVisual(vis.visuals[Visualisation].name); 
		}
        pop();
	};
    
//---------------------------------------------------------------------------//
    
	//DRAW FUNCTION
	this.draw = function()
    {
		push();
		fill("white");
        textSize(32);
		stroke("black");
		strokeWeight(2);
        
        if (menu)
        {
            this.menuDisplayed = false;
        }

		//playback buttons
		this.playbackButton.draw();
        
        vis.selectVisual(vis.visuals[Visualisation].name); 
		//only draw the menu if menu displayed is set to true.
        
		if(this.menuDisplayed)
        {
            translate(0,-200);
            if (dist(mouseX,
                     mouseX, 
                     width,
                     width) > 0 &&
                dist(mouseY,
                    mouseY, 
                    height/1.01,
                    height/1.01) < 200 &&
                menu != true ||
                lock)
            {
                translate(0,200);
            }
            textSize(30);
            textFont("Harlow Solid");
            strokeWeight(2);
            stroke(0);
            fill(255);
			text("Select a visualisation:", 10, 100);
			this.menu();
		}	
		pop();
	};
    
//---------------------------------------------------------------------------//
    
    //MENU FUNCTION
	this.menu = function()
    {
		//draw out menu items for each visualisation
        push();
		for(var i = 0; i < vis.visuals.length; i++)
        {
			var yLoc = 150 + i * 40;
            
            textSize(25);
            textFont("Harlow Solid");
            strokeWeight(2);
            stroke(0);
            fill(255);
            if (i >= 9)
            {
                text("Legacy:  " + vis.visuals[i].name, 
                     10, yLoc);
            }
            else
            {
                text((i+1) + ":  " +vis.visuals[i].name, 
                     10, yLoc);
            }
        }
        pop();
	};
}


