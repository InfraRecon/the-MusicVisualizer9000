//LOADING SCREEN
function loadingScreen()
{
    step = 0.01; //Step for the blobs
    
    this.draw = function()
    {
        push();
        frames = frameCount;
        
        if (loadingS && 
            !startMenu)
        {
            if (frames <= 200) // <-- Loading Time
            {
                fill(randomR,
                     randomG,
                     randomB);

                rect(0,0,width,height);
                
                //Blob Variables
                step;
                n = 50; // number of blobs
                radius = 2; // diameter of the circle
                inter = 1; // difference between the sizes of two blobs
                maxNoise = width;
                noiseProg = (x) => (x*x);
                step = 0.01;
                
                var t = frameCount/250;
                kMax = noise(t/2);
                
                //First Blob
                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, 0, 0, k, t + i * step, noisiness);
                }

                //Second Blob
                for (var i = n; i >= 0; i--) 
                {
                    var alpha = 1 - noiseProg(i / n);
                    fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                    var size = radius + i * inter;
                    var k = kMax * sqrt(i/n);
                    var noisiness = maxNoise * noiseProg(i / n);
                    blob(size, windowWidth, windowHeight, k, t + i * step, noisiness);
                }
                
                //Ball Visual
                fill(255);
                strokeWeight(1);
                stroke(0);
                for(var x = -50; x <= 50; x+=5)
                {
                    for(var y = -50; y <= 50; y+=5)
                    {
                        var d = dist(x, y, 0, 0);
                        var d2 = sin(radians(d))*d;

                        push();
                        translate(x + width -170,y+height -170);
                        angleMode(RADIANS);
                        rotate(radians(d + frameCount));
                        ellipse(x, y, 5, 5);
                        pop();
                    } 
                }
                
                //Loading Screen Text
                stroke(0);
                strokeWeight(5);
                textFont("Harlow Solid");
                fill(255);
                textSize(195);
                text("M  sic",
                     width/2 - 265 + mouseX/width * 10,
                     height/2 + 39 + mouseY/height * 10);
                
                textSize(100);
                text("VisualiZer",
                     width/2 - 175 + mouseX/width * 10,
                     height/2 + 115 + mouseY/height * 10);
                
                textSize(35);
                text("It's over 9000",
                     width/2 - 145 + mouseX/width * 10,
                     height/2 + 155 + mouseY/height * 10);
                
                text("Loading ...",width - 230,height - 50);

                stroke(0);
                strokeWeight(2.5);
                fill(255);
                ellipse(width/2 + mouseX/width * 10,
                        height/2 + mouseY/height * 10,100,100);

                fill(randomR,
                     randomG,
                     randomB);
                triangle(width/2 - 53 + mouseX/width * 10,
                         height/2 - 52 + mouseY/height * 10,
                         width/2 + 45 + mouseX/width * 10,
                         height/2 + mouseY/height * 10,
                         width/2 - 53 + mouseX/width * 10,
                         height/2 + 52 + mouseY/height * 10);

                fill(255);
                triangle(width/2 - 42 + mouseX/width * 10,
                         height/2 - 32 + mouseY/height * 10,
                         width/2 + 25 + mouseX/width * 10,
                         height/2 + mouseY/height * 10,
                         width/2 - 42 + mouseX/width * 10,
                         height/2 + 32 + mouseY/height * 10);
                noFill();
            }
            else
            {
                loadingS = false;
                startMenu = true;
            }
        }
        
        //About the project
        if (about)
        {
            startMenu = false;
            
            fill(randomR,
                 randomG,
                 randomB);
            rect(0,0,windowWidth,windowHeight);
            
            //Blob Variables
            step;
            n = 100; // number of blobs
            radius = 2; // diameter of the circle
            inter = 1; // difference between the sizes of two blobs
            maxNoise = width;
            noiseProg = (x) => (x*x);
            step = 0.01;

            var t = frameCount/250;
            kMax = noise(t/2);
            
            //First Blob
            for (var i = n; i >= 0; i--) 
            {
                var alpha = 1 - noiseProg(i / n);
                fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                var size = radius + i * inter;
                var k = kMax * sqrt(i/n);
                var noisiness = maxNoise * noiseProg(i / n);
                blob(size, 0, 0, k, t + i * step, noisiness);
            }
            
                        //First Blob
            for (var i = n; i >= 0; i--) 
            {
                var alpha = 1 - noiseProg(i / n);
                fill(interpolateSinebow((i/n - t*2)/5, alpha*255));
                var size = radius + i * inter;
                var k = kMax * sqrt(i/n);
                var noisiness = maxNoise * noiseProg(i / n);
                blob(size, width, height, k, t + i * step, noisiness);
            }

            fill(255);
            textFont("Fugaz One");
            strokeWeight(2);
            stroke(0);
            text("About:",
                 100,100,windowWidth - 200);
            text("This Music Visualization Application was created by Roberto Bliaja.",
                 150,150,windowWidth - 200);

            text("My Inspiration:",
                 100,250,windowWidth - 200);
            text("Personally, I love Visulizations and graphics. I work with Graphics every single day ,Improving CGI, Rendering Techniques and Visual User Interactions. My passion for creating and just having fun while doing it is part of everything I do and Create whether it be Code or 3D Animation and Design.",
                 150,300,windowWidth - 200);

            text("How I created the Application:",
                 100,500,windowWidth - 200);
            text("I worked really hard... All Jokes aside, I began researching and studying how the code works with sound.Then I realized that any visual created with code can become a visualization. All it takes is the patience to figure out how would this visual react to Music? What about the visual is great? What method of Implementation should I use?",
                 150,550,windowWidth - 200);

            text("Notes:",
                 100,750,windowWidth - 200);
            text("Thanks for using my Music Visualization Application",
                 150,800,windowWidth - 200); 
            

            stroke(255);
            strokeWeight(2);
            fill(randomR-50,
                 randomG -50,
                 randomB -50);
            if (dist(width - 100,
                    height - 100,
                    mouseX,
                    mouseY) < 50)
            {
                ellipse(width - 100,
                        height - 100,100);
                ellipse(width - 100,
                        height - 100,80);
            }
            else
            {
                ellipse(width - 100,
                        height - 100,100);
            }

            fill(255);
            stroke(0);
            text("Back",
                 width - 100 - 30,
                 height - 90);
            stroke(255);
            strokeWeight(1);
        }
        
        //Filters
        if(Filter == "Standard")
        {
            noFill();
            rect(0,0,windowWidth,windowHeight);
        }

        if(Filter == "Warm")
        {
            fill(255,150,0,20);
            rect(0,0,windowWidth,windowHeight);
        }

        if(Filter == "Cold")
        {
            fill(0,255,255,20);
            rect(0,0,windowWidth,windowHeight);
        }
        
        var frameText = round(frameRate());
        if (showFrames)
        {
            fill(0,255,0);
            stroke(0);
            textSize(20);
            text("FPS: " + frameText,width - 100,20);
        }
        
        //Cursor
        push();
        noFill();
        stroke(255);
        strokeWeight(2);
        
        if (CursorValue == 1)
        {
            ellipse(mouseX,
                    mouseY,50);
            stroke(0);
            ellipse(mouseX,
                    mouseY,54);
            ellipse(mouseX,
                    mouseY,46);
            
            stroke(255);
            ellipse(mouseX,
                    mouseY,10);
            stroke(0);
            ellipse(mouseX,
                    mouseY,14);
            ellipse(mouseX,
                    mouseY,6);
        }
        
        if (CursorValue == 2)
        {
            rect(mouseX - 25,
                 mouseY - 25,50,50,5);
            stroke(0);
            rect(mouseX - 27,
                 mouseY - 27,54,54,5);
            rect(mouseX - 23,
                 mouseY - 23,46,46,5);
            
            stroke(255);
            rect(mouseX - 5,
                 mouseY - 5,10,10);
            stroke(0);
            rect(mouseX - 7,
                 mouseY - 7,14,14);
            rect(mouseX - 3,
                 mouseY - 3,6,6);
        }
        
        if (CursorValue == 3)
        { 
            stroke(255);
            line(mouseX,
                 0,
                 mouseX,
                 mouseY - 12.5);
            line(0,
                 mouseY,
                 mouseX - 12.5,
                 mouseY);
            line(mouseX,
                 height,
                 mouseX,
                 mouseY + 12.5);
            line(width,
                 mouseY,
                 mouseX + 12.5,
                 mouseY);
            
            stroke(255);
            ellipse(mouseX,
                    mouseY,25);
            stroke(0);
            ellipse(mouseX,
                    mouseY,29);
            ellipse(mouseX,
                    mouseY,21);
        }
        
        if (CursorValue == 4)
        {
            strokeWeight(10);
            point(mouseX,
                  mouseY);
            strokeWeight(2);
            stroke(0);
            ellipse(mouseX,
                    mouseY,8,8);
        }
        pop();

        noCursor();
        pop();
    }
}